<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Timehook_model extends CI_Model{
	
	function __construct(){
		parent::__construct();
		$this->load->model("access_control_model", "acl_model");
		$this->load->model("datatable_model","dt_model");
	}

	public function syncpersonnel(){
		echo "<pre>";
		$resultset = array();
		include BASEPATH.'libraries\zklibrary.php';

			//$zk = new ZKLibrary("10.10.10.201", 4370);
			$zk = new ZKLibrary("192.168.7.15", 4370);
			$connected = $zk->connect();
			$resultarray = array();
			if($connected){
				$zk->disableDevice();
				$users = $zk->getUser();
				if($users){
					foreach($users as $key=>$user){
						$data = array();
						$data["biometric_id"] = $user[0];
						$data["biometricno"] = $user[0];
						$data["name"] = $user[1];
						$data["role"] = $user[2];
						$data["is_active"] = 1;
						$resultarray[] = $data;
					}
					
					$resultset["status"] = true;
				}else{
					$resultset["status"] = false;				
				}
			}else{
				$resultset["status"] = false;
			}			

		
		var_dump($resultarray);
	}

	public function syncattendance(){
		include BASEPATH.'libraries\zklibrary.php';

		$deviceName = strtolower("Test");
		$deviceName = preg_replace('/\s+/', '_', $deviceName);
		
		$zk = new ZKLibrary("192.168.7.15", 4370);
		 
		$zk->connect();
		$zk->disableDevice();
		$attendance = $zk->getAttendance();
		$zk->enableDevice();
		$zk->disconnect();
		
		if($attendance){
			$nData = array();
			$nData["attendance_log"] = $attendance;
			$nData["device_id"] = 1;
			
			$dateTime = Date("dYm");
			$filepath = realpath("./uploads/testdata");
			$fileUpload = "{$filepath}/{$deviceName}-{$dateTime}.txt";
			
			$handle = fopen($fileUpload, "w");
			$data = json_encode($nData);
			$response = file_put_contents($fileUpload, $data);
			fclose($handle); 
			/*** chmod($fileUpload, 0777); ***/
		}

		//$urs = $fileUpload;
		return $fileUpload;

		//force_download($fileUpload, null);
	}

}