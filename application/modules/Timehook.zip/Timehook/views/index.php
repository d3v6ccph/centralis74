<?php
 error_reporting(1);
 $this->timehook->syncattendance();
?>