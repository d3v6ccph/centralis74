<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Timehook extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("core/settings_model","settings");
		$this->load->model("timehook_model","timehook");

		date_default_timezone_set('Asia/Manila');
	}
	
	public function index(){		
		$this->load->view('core/templates/header');
		$this->load->view('index');
		$this->load->view('core/templates/footer');
	}

	function syncAttendance(){
		$this->timehook->syncattendance();
	}

	function download(){
		force_download($fileUpload, null);
	}

}