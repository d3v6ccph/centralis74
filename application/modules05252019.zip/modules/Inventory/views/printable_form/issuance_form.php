<div id="printable_issuance-form" align="center">
<style>
img#header-logo {
    max-width: 135px;
	position: relative;
    left: 50px;
}
#form-input_content span {
	width: 210px;
	/* border-bottom: 0.5px solid #000000; */
	display: inline-block;
}
table#form-input_table {
	border-collapse: collapse;
} 
table#form-input_table, table#form-input_table th, table#form-input_table td {
	border: 1px solid #000000;
}
div.form-title-container h3, div.form-title-container p {
	margin: 0;
}
div#printable_issuance-form p, div#printable_issuance-form label {
	font-size: 14px;
}
div#printable_issuance-form table th,
div#printable_issuance-form table td{
	font-size: 14px;
}
div.form-header {
    margin-top: 20px;
}

table, th, td {
    text-transform: uppercase;
}
@media print {
	img#header-logo {
		max-width: 135px;
		position: relative;
		left: 50px;
	}
	#form-input_content span {
		width: 210px;
		/* border-bottom: 0.5px solid #000000; */
		display: inline-block;
	}
	table#form-input_table {
		border-collapse: collapse;
	} 
	table#form-input_table, table#form-input_table th, table#form-input_table td {
		border: 1px solid #000000;
	}
	div.form-title-container h3, div.form-title-container p {
		margin: 0;
	}
	div#printable_issuance-form p, div#printable_issuance-form label {
		font-size: 14px;
	}
	div#printable_issuance-form table th,
	div#printable_issuance-form table td{
		font-size: 14px;
	}
	div#printable_issuance-form {
		margin: 15px 0px;
	}
	div.form-header {
		margin-top: 20px;
	}
	table, th, td {
		text-transform: uppercase;
	}	
}
</style>
<div class="form-header">
	<table width="780">
		<tbody>
			<tr>
				<td style="vertical-align: top;">
					<div class="form-title-container">
						<table width="100%">
							<thead>
								<tr>
									<td align="center">
										<h3>ISSUANCE SLIP<?php echo (isset($core_data->site_name) && $core_data->site_name)? " - ".strtoupper($core_data->site_name):""; ?></h3>
									</td>
								</tr>
								<tr>
									<td align="center">
										<p><small><span>PRX-200 / FORM 05-028</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>Rev</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>12/22/18</span></small></p>
									</td>
								</tr>
							</thead>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="form-body">
<table width="780">
	<tbody>
		<tr>
			<td align="center">
				<table id="form-input_content" width="100%" cellpadding="0" cellspacing="0">
					<tbody>
						<tr>
							<td>
								<table width="100%" cellpadding="2" cellspacing="0">
									<col width="15%">
									<col width="50%">
									<col width="15%">
									<col width="20%">
									<tbody>
										<tr>
											<td><strong>Issued to:</strong></td>
											<td><?php echo (isset($issuance_data->name) && $issuance_data->name)? strtoupper($issuance_data->name): "&nbsp;"; ?></td>
											<td><strong>IS#:<strong></td>
											<td><?php echo (isset($issuance_data->reference_no) && $issuance_data->reference_no)? $issuance_data->reference_no: "&nbsp;"; ?></td>
										</tr>
										<tr>
											<td><strong>Charge to:</strong></td>
											<td><?php echo (isset($issuance_data->charge_to) && $issuance_data->charge_to)? strtoupper($issuance_data->charge_to): "&nbsp;"; ?></td>
											<td><strong>Date:</strong></td>
											<td><?php echo (isset($issuance_data->issued_date) && $issuance_data->issued_date)? date("m/d/Y", strtotime($issuance_data->issued_date)): "&nbsp;"; ?></td>
										</tr>
										<tr>
											<td><strong>WS#:</strong></td>
											<td><?php echo (isset($issuance_data->ws_no) && $issuance_data->ws_no)? strtoupper($issuance_data->ws_no): "&nbsp;"; ?></td>
											<td><strong>APPROVED BY:</strong></td>
											<td><?php echo (isset($issuance_data->approved_by) && $issuance_data->approved_by)? strtoupper($issuance_data->approved_by): "&nbsp;"; ?></td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="line-height: 5px; height: 5px;">&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table id="form-input_table" width="100%" cellpadding="3" cellspacing="0">
					<col width="15%">
					<col width="8%">
					<col width="8%">
					<col width="35%">
					<col width="34%">
					<thead>
						<th align="left">Stock Code</th>
						<th align="center">Qty</th>
						<th align="center">Unit</th>
						<th align="center">Item Description</th>
						<th align="center">Purpose</th>
					</thead>
					<tbody>
						<?php if($issuance_item): ?>
						<?php foreach($issuance_item as $data): ?>
						<tr>
							<td align="left"><?php echo (isset($data->sku) && $data->sku)? strtoupper($data->sku): ""; ?></td>
							<td align="center"><?php echo (isset($data->qty) && $data->qty)? $data->qty: ""; ?></td>
							<td align="center"><?php echo (isset($data->uom_code) && $data->uom_code)? strtoupper($data->uom_code): ""; ?></td>
							<td><?php echo (isset($data->name) && $data->name)? strtoupper($data->name): ""; ?></td>
							<td><?php echo (isset($data->purpose) && $data->purpose)? strtoupper($data->purpose): ""; ?></td>
						</tr>
						<?php endforeach; ?>
						<?php else: ?>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<?php endif; ?>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>
</div>
<div class="form-footer">
<table width="780">
	<tbody>
		<tr>
			<td style="line-height: 25px; height: 25px;">&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table id="form-input_content" width="100%" cellpadding="0" cellspacing="0">
					<tbody>
						<tr>
							<td align="left">
								<div class="content-input-1">
									<label><strong>Received By:</strong></label>
									<span style="margin-left: 10px;"><?php echo (isset($issuance_data->received_by) && $issuance_data->received_by)? strtoupper($issuance_data->received_by): "&nbsp;"; ?></span>
								</div>
							</td>
							<td align="right">
								<div class="content-input-2">
									<label><strong>Issued By:</strong></label>
									<span style="margin-left: 10px; text-align: left;"><?php echo (isset($issuance_data->issued_by) && $issuance_data->issued_by)? strtoupper($issuance_data->issued_by): "&nbsp;"; ?></span>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
</table>
</div>
<script>
setTimeout(function(){
	window.print();
	window.close();
}, 200);
</script>
</div>