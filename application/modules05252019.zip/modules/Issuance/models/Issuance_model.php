<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Issuance_model extends CI_Model{
	protected $issuanceTable = "issuance";
	protected $itemsTable = "items";
	
	function __construct(){
		parent::__construct();
		$this->load->model("access_control_model", "acl_model");
		$this->load->model("datatable_model","dt_model");
	}

	function getIssuanceList(){
		$post = $this->input->post();
		if($post){
			$columns = array("issuance.id", "issuance.reference_no", "issuance.ws_no", "contractors.name", "issuance.received_by", "issuance.charge_to", "issuance.created_by", "issuance.created_at", "issuance.issued_date");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable("issuance");
			
			$dtInventoryItems->setParameterFields($columns);
			
			$joinTable = array();
			$joinTable["table"]["contractors"] = "contractors";
			$joinTable["fields"][] = "issuance.issued_to = contractors.id";
			$joinTable["field_loc"][] = "LEFT";
			
			$dtInventoryItems->setJoinTable($joinTable);
			$dtInventoryItems->setWhereInField("issuance.id");
			
			$whereParams = array();
			$whereParams["issuance.status"] = 1;
			$dtInventoryItems->setWhereParameters($whereParams);
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$userData = $this->core_layout->getUserData($pst->created_by);
					$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
					
					$nestedData['id'] = $pst->id;
					$nestedData['reference_no'] = $pst->reference_no;
					$nestedData['ws_no'] = $pst->ws_no;
					$nestedData['name'] = $pst->name;
					$nestedData['received_by'] = $pst->received_by;
					$nestedData['charge_to'] = $pst->charge_to;
					$nestedData['issued_date'] = date("m/d/Y", strtotime($pst->issued_date));
					$nestedData['issued_time'] = date("H:i", strtotime($pst->issued_date));
					$nestedData['created_by'] = $displayName;
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}

	function getIssuanceContentTemp(){
		$userData = $this->session->userdata();

		$resultarray = array();
		$query = $this->db->query("SELECT issuance_contents_temp.id,issuance_contents_temp.qty,issuance_contents_temp.purpose,items.name,items.sku,uom.uom_code FROM ((issuance_contents_temp INNER JOIN items ON issuance_contents_temp.item = items.id) LEFT JOIN uom ON uom.id = items.unit) WHERE issuance_contents_temp.logged_id = {$userData["logged_in"]["id"]} ");

		if($query){
			foreach($query->result_array() as $_query){
				$data = array();
				$data[] = $_query["qty"];
				$data[] = $_query["sku"];
				$data[] = $_query["name"];
				$data[] = $_query["uom_code"];
				$data[] = $_query["purpose"];
				$action = "";
				$action .= "<button type='button' class='btn btn-default m-btn m-btn--hover-success m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='".$_query["id"]."'><i class='la la-edit'></i></button> ";
				$action .= "<button type='button' class='btn btn-default m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill btnRemoveItem' data-id='".$_query["id"]."'><i class='la la-trash'></i></button>";
				$data[] = $action;
				
				$resultarray[] = $data;
			}
		}
		return array("data"=>$resultarray);
	}

	function addIssuanceContentTemp(){
		$userData = $this->session->userdata();
		$post = $this->input->post();
		$post["logged_id"] = $userData["logged_in"]["id"];
		if($post){
			$checkItemIfSelected = $this->checkItemIfSelected($post["item"]);
			if($checkItemIfSelected){
				$checkqty = $this->checkqty($post["qty"], $post["item"]);
				if($checkqty){ 
					$session = $this->core_layout->getCurrentSession();
					
					$insertItem = $this->db->insert("issuance_contents_temp",$post);
					if($insertItem){
						$result["response"] = TRUE;
						$result["toastr_msg"] = "Item successfully added.";
					}else{
						$result["response"] = FALSE;
						$result["toastr_msg"] = "Error processing request!";
					}
				}else{
					$result["response"] = FALSE;
					$result["toastr_msg"] = "Insufficient stocks!";
				}
			}else{
				$result["response"] = FALSE;
				$result["toastr_msg"] = "Item already selected!";
			}
		}else{  
			$result["response"] = FALSE;
			$result["toastr_msg"] = "No available data for saving!";
		}
		
		return $result;
	}

	function getItemData($post = array()){
		if(isset($post["id"]) && $post["id"]){
			$query = $this->db->query("SELECT items.id, items.name, items.sku, items.qty, items.reorder_qty, uom.uom_code FROM items LEFT JOIN uom ON items.unit = uom.id WHERE items.id = {$post['id']}");
			if($query->num_rows() == 1){
				$row = $query->row_array();
				if(isset($row["qty"], $row["reorder_qty"]) && $row["qty"] <= $row["reorder_qty"] && $row["reorder_qty"] > 0){
				$row["pop_message"] = "This item `{$row['name']}` has reached its minimum re-order limit of ({$row['reorder_qty']}) {$row['uom_code']}, current quantity is {$row['qty']} {$row['uom_code']}.";
				}
				
				return $row;
			}else{
				return false;
			}
		}else{
			return false;
		}
		/* return $query ? $query->row_array() : false; */
	}

	function checkqty($qty = 0,$item = NULL){
		$issueItem = false;
		$query = $this->db->get_where($this->itemsTable, array("id"=>$item));
		if($query->num_rows() == 1){
			$row = $query->row();
			
			$stockQty = floatval($row->qty);
			$neededQty = floatval($qty);
			$beginningQty = floatval($row->beginning_qty);
			
			if($beginningQty == 0){ $issueItem = true; }
			if($beginningQty > 0 && ($neededQty <= $stockQty)){ $issueItem = true; }
		}
		
		return $issueItem;
	}

	function checkItemIfSelected($item = NULL){
		$query = $this->db->query("SELECT * FROM issuance_contents_temp WHERE item = {$item}");
		return $query->num_rows() == 0 ? true : false;
	}

	function saveIssuance(){
		$userData = $this->session->userdata();
		$post = $this->input->post();
		$resultarray = array();
		$session = $this->core_layout->getCurrentSession();
		$post["created_by"] = $session["emp_id"];
		$post["issued_date"] = (isset($post["issued_date"]) && $post["issued_date"])? date("Y-m-d H:i:00", strtotime($post["issued_date"])) : date("Y-m-d H:i:00");
		
		$post["received_by"] = strtoupper($post["received_by"]);
		$post["charge_to"] = strtoupper($post["charge_to"]);
		$post["ws_no"] = strtoupper($post["ws_no"]);
		$post["reference_no"] = $this->getrefGen();
		
		$query = $this->db->insert("issuance", $post);
		$issuance_id = $this->db->insert_id(); 
		$resultarray["id"] = $issuance_id;
		
		$getContentTemp = $this->db->get_where('issuance_contents_temp',array("logged_id"=>$userData["logged_in"]["id"]));

		if($query){
			foreach($getContentTemp->result_array() as $_getContentTemp){
				$this->db->insert("issuance_contents",array('issuance_id'=>$issuance_id,"item"=>$_getContentTemp["item"],"qty"=>$_getContentTemp["qty"],"purpose"=>$_getContentTemp["purpose"]));
				$this->updateItem(array("qty"=>$_getContentTemp["qty"],"item"=>$_getContentTemp["item"]));
				$this->db->delete('receiving_contents_temp', array('id' => $_getContentTemp['id'])); 
			}
			$this->db->query("TRUNCATE TABLE issuance_contents_temp");
			$resultarray["status"] = TRUE;
			$resultarray["toastr_msg"] = "Data successfully saved.";
		}else{
			$resultarray["status"] = FALSE;
			$resultarray["toastr_msg"] = "Error processing request.";
		}

		return $resultarray;
	}

	function updateItem($data = array()){
		$qty = 0;
		$getItemQty = $this->db->query("SELECT qty FROM items WHERE id = {$data['item']}");
		$itemData = $getItemQty->row_array();
		$qty = $itemData["qty"] - $data["qty"];

		$this->db->set(array("qty"=>$qty));
		$this->db->where(array("id"=>$data["item"]));
		$query = $this->db->update("items");

		return $query ? true : false;
	}
	
	function udpdateIssuanceRowContent(){
		$resultset = array();
		$post = $this->input->post();
		if(isset($post) && $post){
			$id = $post["id"];
			unset($post["id"]);
			
			$update = $this->db->update("issuance_contents_temp", $post, array("id"=>$id));
			if($update){
				$resultset["response"] = true;
			}else{
				$resultset["response"] = false;	
			}
		}else{
			$resultset["response"] = false;				
		}
		
		return $resultset;
	}
	
	function getIssuance($post = array()){
		$query = $this->db->query("SELECT issuance.id,issuance.issued_date,issuance.charge_to,issuance.approved_by,issuance.received_by,issuance.reference_no,issuance.ws_no,contractors.name FROM issuance LEFT JOIN contractors ON issuance.issued_to = contractors.id WHERE issuance.id = {$post['id']}");
		return $query ? $query->row_array() : false;
	}

	function getIssuanceContent($post = array()){
		$resultarray = array();
		$query = $this->db->query("SELECT issuance_contents.id,issuance_contents.qty,issuance_contents.purpose,items.name,items.sku,uom.uom_code FROM ((issuance_contents INNER JOIN items ON issuance_contents.item = items.id) LEFT JOIN uom ON uom.id = items.unit) WHERE issuance_contents.issuance_id = {$post['id']}");

		if($query){
			foreach($query->result_array() as $_query){
				$data = array();
				$data[] = $_query["sku"];
				$data[] = $_query["uom_code"];
				$data[] = $_query["qty"];
				$data[] = $_query["name"];
				$data[] = $_query["purpose"];

				$resultarray[] = $data;
			}
		}
		return array("data"=>$resultarray);
	}
	
	function getIssuanceContentData(){
		$post = $this->input->post();
		
		$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
		$recordsTotal = 0;
		
		$resultset = array();
		$data = array();
		
		$SQL_query = "";
		$SQL_query .= "SELECT issuance_contents.id,issuance_contents.qty,issuance_contents.purpose,items.name,items.sku,uom.uom_code ";
		$SQL_query .= "FROM ((issuance_contents INNER JOIN items ON issuance_contents.item = items.id) LEFT JOIN uom ON uom.id = items.unit) ";
		$SQL_query .= "WHERE issuance_contents.issuance_id = {$post['id']}";
		
		$query = $this->db->query($SQL_query);
		if($query->num_rows() > 0){
			$recordsTotal = $query->num_rows();
			
			foreach($query->result_array() as $_query){
				$row = array();
				$row[] = trim($_query["sku"]);
				$row[] = $_query["uom_code"];
				$row[] = $_query["qty"];
				$row[] = trim($_query["name"]);
				$row[] = $_query["purpose"];
				$action = "";
				$action .= "<button type='button' class='btn btn-default m-btn m-btn--hover-success m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='".$_query["id"]."'><i class='la la-edit'></i></button> ";
				$row[] = $action;
				$data[] = $row;
			}
		}
		
		$resultset["draw"] = intval($draw);
		$resultset["recordsTotal"] = intval($recordsTotal);  
        $resultset["recordsFiltered"] = intval($recordsTotal); 
		$resultset["data"] = $data;
		
		return array("data"=>$data);
	}
	
	function removeItemContentTemp(){
		$resultarray = array();
		$post = $this->input->post();
		$query = $this->db->delete("issuance_contents_temp",$post);
		if($query){
			$resultarray["toastr_msg"] = "Item successfully removed.";
			$resultarray["status"] = TRUE;
		}else{
			$resultarray["toastr_msg"] = "Error received item.";
			$resultarray["status"] = FALSE;
		}
		return $resultarray;
	}
	
	function getIssuanceRowContent(){
		$resultset = array();
		$post = $this->input->post();
		if(isset($post["id"]) && $post["id"]){
			$this->db->select("a.id, a.purpose, a.qty, b.name, b.sku, c.uom_code as unit");
			$this->db->from("issuance_contents_temp a");
			$this->db->join("items b", "b.id = a.item", "left");
			$this->db->join("uom c", "c.id = b.unit", "left");
			$this->db->where("a.id", $post["id"]);
			$query = $this->db->get();
			if($query->num_rows() == 1){
				$resultset["response"] = true;
				$resultset["value"] = $query->row();
			}else{
				$resultset["response"] = false;				
			}
		}else{
			$resultset["response"] = false;
		}
		
		return $resultset;
	}

	function updateIssuanceData(){
		$post = $this->input->post();
		$resultarray = array();
		
		$where = array();
		$where["id"] = $post["id"];
		unset($post["id"]);
		
		$query = $this->db->update("issuance", $post, $where);

		if($query){
			$resultarray["response"] = TRUE;
			$resultarray["toastr_msg"] = "Issuance successfully updated.";
		}else{
			$resultarray["response"] = FALSE;
			$resultarray["toastr_msg"] = "Error processing request.";
		}

		return $resultarray;
	}

	function getIssuanceItemData(){
		$post = $this->input->post();

		$sql = $this->db->query("SELECT purpose,id FROM issuance_contents WHERE id = {$post['id']}");
		$query = $sql->row_array();

		return $query;
	}

	function updateIssuanceItem(){
		$post = $this->input->post();

		$this->db->set(array("purpose"=>$post["purpose"]));
		$this->db->where(array("id"=>$post["id"]));
		$query = $this->db->update("issuance_contents");

		if($query){
			$resultarray["response"] = TRUE;
			$resultarray["toastr_msg"] = "Issuance successfully updated.";
		}else{
			$resultarray["response"] = FALSE;
			$resultarray["toastr_msg"] = "Error processing request.";
		}

		return $resultarray;
	}
	
	function getAllReceivedBy(){
		$arrData = array();
		$this->db->select("received_by");
		$this->db->from("issuance");
		$this->db->order_by("received_by", "ASC");
		$this->db->group_by("received_by");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$arrData[] = $rs->received_by;
			}
		}
		
		return $arrData;
	}
	
	function getAllChargedTo(){
		$arrData = array();
		$this->db->select("charge_to");
		$this->db->from("issuance");
		$this->db->order_by("charge_to", "ASC");
		$this->db->group_by("charge_to");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$arrData[] = $rs->charge_to;
			}
		}
		
		return $arrData;
	}

	function getAllApprovedBy(){
		$arrData = array();
		$this->db->select("approved_by");
		$this->db->from("issuance");
		$this->db->order_by("approved_by", "ASC");
		$this->db->group_by("approved_by");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$arrData[] = $rs->approved_by;
			}
		}
		
		return $arrData;
	}
	
	function cancelIssuance(){
		$post = $this->input->post();
		$resultset = array();
		if($post){
			$session = $this->core_layout->getCurrentSession();
			
			$where = array();
			$where["id"] = $post["id"];
			
			$data = array();
			$data["status"] = 0;
			$data["cancel_remarks"] = $post["cancel_remarks"];
			$data["cancelled_by"] = $session["emp_id"];
			$data["cancelled_at"] = date("Y-m-d H:i:s");
			
			$update = $this->db->update($this->issuanceTable, $data, $where);
			if($update){
				$resultset["response"] = true;
				$resultset["toastr_msg"] = "Issuance slip has been cancelled.";
			}else{
				$resultset["response"] = false;
				$resultset["toastr_msg"] = "Failed to cancel issuance slip";
			}
		}else{
			$resultset["response"] = false;			
			$resultset["toastr_msg"] = "No data found!";
		}
		
		return $resultset;
	}
	
	function getrefGen(){
		$countData = $this->db->count_all_results('issuance');
		$countData = $countData + 1;
		$coreData = $this->settings->getSettingsData();
		$siteCode = (isset($coreData->site_code) && $coreData->site_code)? strtoupper($coreData->site_code):"";
		$countData = str_pad($countData, 5, '0', STR_PAD_LEFT);
		$refgen = ($siteCode)? "IS-{$siteCode}-{$countData}":"IS-{$countData}";

		return $refgen;
	}

	function getIssuanceArchives(){
		$post = $this->input->post();
		if($post){
			$columns = array("issuance.id", "issuance.reference_no", "issuance.ws_no", "contractors.name", "issuance.received_by", "issuance.charge_to", "issuance.created_by", "issuance.created_at", "issuance.issued_date","issuance.status","issuance.cancel_remarks","issuance.cancelled_by","issuance.cancelled_at");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable("issuance");
			
			$dtInventoryItems->setParameterFields($columns);
			
			$joinTable = array();
			$joinTable["table"]["contractors"] = "contractors";
			$joinTable["fields"][] = "issuance.issued_to = contractors.id";
			$joinTable["field_loc"][] = "LEFT";
			
			$dtInventoryItems->setJoinTable($joinTable);
			$dtInventoryItems->setWhereInField("issuance.id");
			
			$whereParams = array();
			$whereParams["issuance.status"] = 0;
			$dtInventoryItems->setWhereParameters($whereParams);
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$userData = $this->core_layout->getUserData($pst->cancelled_by);
					$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
					
					$nestedData['id'] = $pst->id;
					$nestedData['reference_no'] = $pst->reference_no;
					$nestedData['ws_no'] = $pst->ws_no;
					$nestedData['name'] = $pst->name;
					$nestedData['cancelled_date'] = date("m/d/Y", strtotime($pst->cancelled_at));
					$nestedData['cancelled_time'] = date("H:i", strtotime($pst->cancelled_at));
					$nestedData['cancelled_by'] = $displayName;
					$nestedData['cancel_remarks'] = $pst->cancel_remarks;
					$nestedData['btn'] = "<button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnViewarchivedContents' data-id='".$pst->id."'><i class='la 	la-file-text'></i></button>";
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}
}