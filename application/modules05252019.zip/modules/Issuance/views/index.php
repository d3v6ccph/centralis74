<?php $actions = $this->core_layout->getCurrentActions(); ?>
<?php $issuanceChargedTo = $this->issuance->getAllChargedTo(); ?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Issuance
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item m-dropdown m-dropdown--inline m-dropdown--arrow m-dropdown--align-right m-dropdown--align-push" data-dropdown-toggle="hover" aria-expanded="true">
								<a href="#" class="m-portlet__nav-link m-portlet__nav-link--icon m-portlet__nav-link--icon-xl">
									<i class="la la-ellipsis-h m--font-brand"></i>
								</a>
								<div class="m-dropdown__wrapper">
									<span class="m-dropdown__arrow m-dropdown__arrow--right m-dropdown__arrow--adjust" style="left: auto; right: 22.5px;"></span>
									<div class="m-dropdown__inner">
										<div class="m-dropdown__body">
											<div class="m-dropdown__content">
												<ul class="m-nav">
													<li class="m-nav__section m-nav__section--first">
														<span class="m-nav__section-text">
															Quick Action
														</span>
													</li>
													<li class="m-nav__item">
														<a href="javascript:void()" class="m-nav__link" data-toggle="modal" data-target="#modal_archives">
															<i class="m-nav__link-icon flaticon-open-box"></i>
															<span class="m-nav__link-text">
																Archives
															</span>
														</a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-issuance" width="100%">
								<thead>
									<tr>
										<th>Reference #</th>
										<th>WS #</th>
										<th>Issued To</th>
										<th>Charge To</th>
										<th>Received By</th>
										<th>Date</th>
										<th>Time</th>
										<th>Issued By</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
			<!--end::Portlet-->
		</div>
	</div>
</div>


<!-- Modal View Transaction Begin -->
<div class="modal fade" id="modal-view-issuance" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="display: none; z-index: 9999;" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Issuance View</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">
						×
					</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Issued To:
								</label>
								<input type="text" name="issued_to" disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Reference No.:
								</label>
								<input type="text" name="reference_no"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Received By:
								</label>
								<input type="text" name="received_by"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Withdrawal Slip #:
								</label>
								<input type="text" name="ws_no"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Charge To:
								</label>
								<input type="text" name="charge_to"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Issued Date:
								</label>
								<input type="text" name="issued_date"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll col-md-12">
							<div class="row">
								<div class="col-md-12">
									<table class="table table-striped table-bordered m-datatable__table" id="table-issuance-contents" width="100%">
										<thead>
											<tr>
												<th>Stock Code</th>
												<th>Unit</th>
												<th>Qty</th>
												<th>Item Description</th>
												<th>Purpose</th>
											</tr>
										</thead>
										<tbody>	

										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
				<button class="btn btn-primary btnPrint">Print</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-view-issuance_data" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document" style="max-width: 1200px;">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Issuance Edit</h5>
			</div>
			<div class="modal-body">
				<form id="frmIssuanceView" method="post" action="<?php echo site_url("issuance/update_issuance_data"); ?>">
				<input type="hidden" name="id" v-model="item_update.id" />
				<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>Issued To:</label>
								<input type="text" name="issued_to" disabled="disabled" class="form-control m-input" data-validation="required" v-model="item_update.issued_to">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Reference No.:
								</label>
								<input type="text" name="reference_no"  disabled="disabled" class="form-control m-input" data-validation="required" v-model="item_update.reference_no">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Received By:
								</label>
								<input type="text" name="received_by"  disabled="disabled" class="form-control m-input" data-validation="required" v-model="item_update.received_by">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Withdrawal Slip #:
								</label>
								<input type="text" name="ws_no"  disabled="disabled" class="form-control m-input" data-validation="required">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Charged To:
								</label>
								<div class="m-typeahead">
									<input id="m_typeahead_2" type="text" name="charge_to" class="form-control m-input" data-validation="required" v-model="item_update.charge_to" autocomplete="off">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Issued Date:
								</label>
								<input type="text" name="issued_date"  disabled="disabled" class="form-control m-input" data-validation="required" v-model="item_update.issued_to">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Approved By:
								</label>
								<input type="text" name="approved_by"  disabled="disabled" class="form-control m-input" data-validation="required" v-model="item_update.approved_by">
							</div>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll col-md-12">
							<div class="row">
								<div class="col-md-12">
									<table class="table table-striped table-bordered m-datatable__table" id="table-issuance-edit-contents" width="100%">
										<col width="12%">
										<col width="10%">
										<col width="10%">
										<col width="28%">
										<col width="35%">
										<col width="5%">
										<thead>
											<tr>
												<th>Stock Code</th>
												<th>Unit</th>
												<th>Qty</th>
												<th>Item Description</th>
												<th>Purpose</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="modal-footer">
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary btnUpdate">Update</button>
			</div>
		</div>
		</form>
	</div>
</div>

<div class="modal fade" id="modal-view-issuance_item" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-sm" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Issuance Item Edit</h5>
			</div>
			<div class="modal-body">
				<form id="frmIssuanceItemView" method="post" action="<?php echo site_url("issuance/update_issuance_item"); ?>">
				<input type="hidden" name="id" v-model="item_update.id" />
				
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label class="form-control-label">
								Purpose
							</label>
							<textarea class="form-control m-input" name="purpose" data-validation="required" rows="3"></textarea>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary btnUpdate">Update</button>
			</div>
		</div>
		</form>
	</div>
</div>
<!-- Modal View Transaction End -->
<div class="modal fade" id="modal_cancel_remarks" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-m" role="document">
		<form id="formCancel" action="<?php echo site_url('issuance/cancel_issuance'); ?>" method="POST">
			<input type="hidden" name="id">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Cancel Issuance Transaction</h5>
				</div>
				<div class="modal-body">
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group m-form__group">
									<label>
										Reason for cancellation:
									</label>
									<textarea class="form-control m-input" name="cancel_remarks" data-validation="required"></textarea>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-danger" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary btn-submit btnDelete">Proceed</button>
				</div>
			</div>
		</form>
	</div>
</div>

<!-- Modal Archives Begin -->
<div class="modal fade" id="modal_archives" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document" style="max-width: 80%;">		
		<div class="modal-content" >
			<div class="modal-header">
				<h5 class="modal-title">
					Issuance Archives
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">
						×
					</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
					<table class="table table-striped table-bordered" id="table-issuance-archives" width="100%">
						<thead>
							<tr>
								<th>Reference #</th>
								<th>WS #</th>
								<th>Issued To</th>
								<th>Date</th>
								<th>Time</th>
								<th>Cancelled By</th>
								<th>Remarks</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>	
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Modal Archives End -->

<script type="text/javascript">
var _currentActions = <?php echo json_encode($actions); ?>;
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";
var _global_id = 0;

var _modalPrint = $("#modal-view-issuance");
var _issuanceChargedTo = [];
<?php if(isset($issuanceChargedTo) && $issuanceChargedTo): ?>
_issuanceChargedTo = <?php echo json_encode($issuanceChargedTo); ?>;
<?php endif; ?>

var _dtUserRole = $("#table-issuance").DataTable({
	dom: '<"toolbar">frtlip',
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("issuance/get_issuance_list"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "reference_no", width: "8%" },
		{ data: "ws_no", width: "8%" },
		{ data: "name", width: "16%" },
		{ data: "charge_to", width: "16%" },
		{ data: "received_by", width: "15%" },
		{ data: "issued_date", width: "10%" },
		{ data: "issued_time", width: "5%" },
		{ data: "created_by", width: "15%" },
		{ data: "", width: "7%"},
	], columnDefs: [{
		data: null,
		defaultContent: "",
		targets: -1,
		orderable: false,
		render: function ( data, type, row, meta ) { return itemDatatableActions(row.id); },
	}, { 
		targets: "_all", 
		defaultContent: "", 
	}],
	order: [[ 0, "desc" ]],
	initComplete: function(settings, json){
		if(typeof roleActionUpdate == "function"){ roleActionUpdate(); }
	}
});

$("div.toolbar").html('<button type="button" id="issuance-new" class="m-portlet__nav-link btn m-btn--square btn-success btnNew"  data-toggle="modal" data-target="#modal-issuance-new"><i class="fa fa-plus"></i> New </button>');

function itemDatatableActions($id){
	if($id){
		var _actionButton ="";
		if(typeof _currentActions !== "undefined" && jQuery.inArray("edit", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='"+$id+"'><i class='la la-edit'></i></button>";				
		}
		if(typeof _currentActions !== "undefined" && jQuery.inArray("print", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnPrintItem' data-id='"+$id+"'><i class='la la-print'></i></button>";				
		}
		if(typeof _currentActions !== "undefined" && jQuery.inArray("delete", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill btnRemoveItem' data-id='"+$id+"'><i class='la la-ban'></i></button>";				
		}
		return _actionButton;
	}else{ return false; }
}

var dt_issuanceArchives = $("#table-issuance-archives").DataTable({
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo site_url("issuance/get_issuance_archives"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	},
	columns: [
		{ data: "reference_no"},
		{ data: "ws_no"},
		{ data: "name"},
		{ data: "cancelled_date"},
		{ data: "cancelled_time"},
		{ data: "cancelled_by"},
		{ data: "cancel_remarks"},
		{ data: "btn"},
	]
});

//navigate to add new page
$("#issuance-new").on("click",function(){
	window.location.href = "<?php echo site_url('issuance/add_new_page')?>";
});

//view issuance archives on modal
$("#table-issuance-archives").on("click",".btnViewarchivedContents",function(){
	var id = $(this).attr("data-id");
	$("#modal-view-issuance").modal("show");
	$.ajax({
		url: "<?php echo site_url('issuance/getIssuance'); ?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success:function(data){
			$("input[name='issued_to']").val(data.name);
			$("input[name='reference_no']").val(data.reference_no);
			$("input[name='ws_no']").val(data.ws_no);
			$("input[name='issued_by']").val(data.created_by);
			$("input[name='date']").val(data.created_at);
			$("input[name='received_by']").val(data.received_by);
			$("input[name='charge_to']").val(data.charge_to);
			$("input[name='approved_by']").val(data.approved_by);
			$("input[name='issued_date']").val(moment(data.issued_date).format("MM/DD/YYYY HH:mm"));
			
			$("#modal-view-issuance").find(".btnPrint").attr("data-id", id);
			_global_id = id;
			dtModalTable.ajax.reload();
		}
	});
});

//view issuance transaction on modal
$("#table-issuance").on("click",".btnPrintItem",function(){
	var id = $(this).attr("data-id");
	$("#modal-view-issuance").modal("show");
	$.ajax({
		url: "<?php echo site_url('issuance/getIssuance'); ?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success:function(data){
			$("input[name='issued_to']").val(data.name);
			$("input[name='reference_no']").val(data.reference_no);
			$("input[name='ws_no']").val(data.ws_no);
			$("input[name='issued_by']").val(data.created_by);
			$("input[name='date']").val(data.created_at);
			$("input[name='received_by']").val(data.received_by);
			$("input[name='charge_to']").val(data.charge_to);
			$("input[name='approved_by']").val(data.approved_by);
			$("input[name='issued_date']").val(moment(data.issued_date).format("MM/DD/YYYY HH:mm"));
			
			$("#modal-view-issuance").find(".btnPrint").attr("data-id", id);
			_global_id = id;
			dtModalTable.ajax.reload();
		}
	});
});

$("#table-issuance").on("click",".btnEditItem", function(){
	var id = $(this).attr("data-id");
	$.ajax({
		url: "<?php echo site_url('issuance/getIssuance'); ?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success:function(data){
			_global_id = id;
			
			//render data on form
			$("#frmIssuanceView input[name='id']").val(data.id);
			$("#frmIssuanceView input[name='issued_to']").val(data.name);
			$("#frmIssuanceView input[name='reference_no']").val(data.reference_no);
			$("#frmIssuanceView input[name='ws_no']").val(data.ws_no);
			$("#frmIssuanceView input[name='issued_by']").val(data.created_by);
			$("#frmIssuanceView input[name='date']").val(data.created_at);
			$("#frmIssuanceView input[name='received_by']").val(data.received_by);
			$("#frmIssuanceView input[name='charge_to']").val(data.charge_to);
			$("#frmIssuanceView input[name='approved_by']").val(data.approved_by);
			$("#frmIssuanceView input[name='issued_date']").val(moment(data.issued_date).format("MM/DD/YYYY HH:mm"));

			$("#modal-view-issuance_data").modal("show");
			dtModalEditTable.ajax.reload();
		}
	});
});

jQuery(document).on("click", "#table-issuance .btnRemoveItem", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	$("#modal_cancel_remarks input[name=id]").val(dataId);
	$("#modal_cancel_remarks").modal("show");
});

$.validate({
	form : '#formCancel',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			dataType: "json",
			data: $("#formCancel").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(json){
				if(json.response){
					toastr.success(json.toastr_msg, "Cancelled Issuance", 5000);
					$("#modal_cancel_remarks").modal("hide");
					setTimeout(function(){
						_dtUserRole.ajax.reload();						
						dt_issuanceArchives.ajax.reload();						
					}, 500);
				}else{
					toastr.error(json.toastr_msg, "Error Cancelled Issuance", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
			}
		});
		return false;
	},
});


var dtModalTable = $("#table-issuance-contents").DataTable({
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("issuance/get_issuance_content"); ?>",
		type: "post",
		dataType: "json",
		data: function(parameter){
			parameter.id = _global_id; 
		},
	},
	lengthChange: false,
	bInfo : false,
	paging:   false,
	searching: false
});

//validate edit
$.validate({
	form : '#frmIssuanceView',
	lang: 'en',
	onSuccess : function(form) {
		var _url = form[0].action;
		var _data = jQuery(form[0]).serialize();
		var _btnSubmit = $(form[0]).find(".btnUpdate");
		
		$.ajax({
			url: _url,
			type: "POST",
			dataType: "json",
			data: _data,
			beforeSend: function(){
				if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
			},
			success: function(data){
				if(data.response){
					toastr.success(data.toastr_msg, "Update Issuance", 5000);
					$("#modal-view-issuance_data").modal("hide");
					setTimeout(function(){ _dtUserRole.ajax.reload(); }, 500);
				}else{
					toastr.error(data.toastr_msg, "Error Issuance", 5000);
				}
				if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
			}
		});
		
		return false;
	}
});

var dtModalEditTable = $("#table-issuance-edit-contents").DataTable({
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("issuance/get_issuance_content_data"); ?>",
		type: "post",
		dataType: "json",
		data: function(parameter){
			parameter.id = _global_id; 
		},
	},
	columnDefs: [{ 
		targets: [ 4, -1 ],
		orderable: false,
	}],
	lengthChange: false,
	bInfo : false,
	paging:   false,
	searching: false
});

//show modal edit purpose
$("#table-issuance-edit-contents").on("click",".btnEditItem", function(){
	var	id = $(this).attr("data-id");
	$("#modal-view-issuance_item").modal("show");

	$.ajax({
		url: "<?php echo site_url('issuance/get_issuance_item_data'); ?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success: function(data){
			$("#modal-view-issuance_item textarea[name=purpose]").val(data.purpose);
			$("#modal-view-issuance_item input[name=id]").val(data.id);
		}
	})
});

//update purpose
$.validate({
	form : '#frmIssuanceItemView',
	lang: 'en',
	onSuccess : function(form) {
		var _url = form[0].action;
		var _data = jQuery(form[0]).serialize();
		var _btnSubmit = $(form[0]).find(".btnUpdate");
		
		$.ajax({
			url: _url,
			type: "POST",
			dataType: "json",
			data: _data,
			beforeSend: function(){
				if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
			},
			success: function(data){
				if(data.response){
					toastr.success(data.toastr_msg, "Update Issuance Item", 5000);
					$("#modal-view-issuance_item").modal("hide");
					dtModalEditTable.ajax.reload();
				}else{
					toastr.error(data.toastr_msg, "Error Issuance Item", 5000);
				}
				if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
			}
		});
		
		return false;
	}
});

jQuery(document).on("click", ".btnPrint", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	var toId = (dataId == _global_id)? dataId: _global_id;
	
	_modalPrint.modal("hide");
	window.open("<?php echo site_url("inventory/printable/print_issuance"); ?>"+"/"+toId, "_blank");
});

$(document).ready(function(){
	issuanceTypeHead();
});
var issuanceTypeHead = function() {
	var substringMatcher = function(strs) {
		return function findMatches(q, cb) {
			var matches, substringRegex;
			matches = [];
			substrRegex = new RegExp(q, 'i');
			$.each(strs, function(i, str) {
				if (substrRegex.test(str)) {
					matches.push(str);
				}
			});

			cb(matches);
		};
	};

	$('#m_typeahead_2').typeahead({
		hint: false,
		highlight: true,
		minLength: 1
	}, {
		name: 'charge_to',
		source: substringMatcher(_issuanceChargedTo)
	});
}
</script>
<style>
.tt-menu { width: 100%; }
</style>