<?php
	$actions = $this->core_layout->getCurrentActions();
	
	$issuanceReceiver = $this->issuance->getAllReceivedBy();
	$issuanceChargedTo = $this->issuance->getAllChargedTo();
	$approvedBy  = $this->issuance->getAllApprovedBy();
	
	
?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
		<form id="add_issuance_form" method="POST" action="<?php echo site_url('issuance/saveIssuance'); ?>">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Issuance New
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Form -->
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Issued To:
									</label>
									<select class="form-control m-select2" id="select2Contractor" name="issued_to" data-validation="required">
										 <option></option>
										<?php 
											$query = $this->db->query("SELECT * FROM contractors WHERE status = 1");
											$contractorCollection = $query->result_array();
											if($contractorCollection){
												foreach($contractorCollection as $_contractorCollection){
													echo "<option value='{$_contractorCollection['id']}'>{$_contractorCollection['name']}</option>";
												}
											}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Withdrawal Slip #:
									</label>
									<input type="text" name="ws_no" class="form-control m-input" data-validation="required" autocomplete="off">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Received By:
									</label>
									<div class="m-typeahead">
										<input id="m_typeahead_1" type="text" name="received_by" class="form-control m-input tt-input" data-validation="required" autocomplete="off">
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Issued Date:
									</label>
									<input id="m_datetimepicker-issued_date" type="text" name="issued_date" class="form-control m-input" readonly placeholder="Select date and time">
								</div>
							</div>							
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Charged To:
									</label>
									<div class="m-typeahead">
										<input id="m_typeahead_2" type="text" name="charge_to" class="form-control m-input tt-input" data-validation="required" autocomplete="off">
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Approved By:
									</label>
									<div class="m-typeahead">
										<input id="m_typeahead_3" type="text" name="approved_by" class="form-control m-input tt-input" data-validation="required" autocomplete="off">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end::Portlet-->
			<!--start:: Content Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Issuance Contents
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								
							</li>
						</ul> 
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Form -->
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-12">
								<table class="table table-striped table-bordered" id="table-issuance-contents" width="100%">
									<col width="5%">
									<col width="10%">
									<col width="30%">
									<col width="5%">
									<col width="42%">
									<col width="8%">
									<thead>
										<tr>
											<th>Qty</th>
											<th>Stock Code</th>
											<th>Item Description</th>
											<th>Unit</th>
											<th>Purpose</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>	

									</tbody>
								</table>
							</div>
						</div>
					</div>	
				</div>
				<div class="m-portlet__foot">
					<div class="row align-items-center">
						<div class="col-lg-6 m--valign-middle">
							
						</div>
						<div class="col-lg-6 m--align-right">
							<button type="submit" class="btn btn-brand btn-submit">Print</button>
							<button type="button" class="btn btn-danger btnCancel btn-cancel_transaction">Cancel</button>
						</div>
					</div>
				</div>
			</div>
			<!--end:: Content Portlet-->
		</form>
		<!--end: Form -->
		</div>
	</div>
</div>

<!-- Model Item Lookup Begin -->
<div class="modal fade" id="modal-item-lookup" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('issuance/add_issuance_content'); ?>" method="POST" id="form-item-new">
			<div class="modal-header"><h5 class="modal-title">Add Item</h5>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">
						Search Item
					</label>
					<select class="form-control select2-hidden-accessible" tabindex="-1" data-validation="required" aria-hidden="true" name="item" style="width: 100% !important;" id="item-collection">
						<option disabled="disabled" selected="selected">Select Item</option>
						<?php
							$itemCollection = $this->crud->getCollection(array(),"items");
							if($itemCollection):
								foreach($itemCollection as $_itemCollection):
									$checkifselected = $this->crud->load(array("item"=>$_itemCollection["id"]),"receiving_contents_temp");
									if(!$checkifselected){
										?>
											<option value="<?php echo $_itemCollection["id"];?>"><?php echo $_itemCollection["sku"] ." | ". $_itemCollection["name"];?></option>
										<?php
									}
								endforeach; 
							endif;
						?>
					</select>
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Item Description
					</label>
					<input type="text" class="form-control m-input" disabled="disabled" name="name">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Stock Code
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="sku">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Unit
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="unit">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Quantity
					</label>
					<input type="number" class="form-control m-input" step="any" name="qty" data-validation-allowing="float" data-validation="required">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Purpose
					</label>
					<textarea class="form-control m-input" name="purpose" data-validation="required" rows="3"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success btnCancel" data-dismiss="modal">Preview</button>
				<button type="submit" class="btn btn-primary btn-submit btnSave">Add</button>
			</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-item-update_lookup" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('issuance/update_issuance_row_ccontent'); ?>" method="POST" id="form-item-update">
			<input type="hidden" name="id" v-model="item_update.id" />
			<div class="modal-header"><h5 class="modal-title">Update Item</h5>
			</div>
			<div class="modal-body">
				<div class="form-group ">
					<label class="form-control-label">
						Item Description
					</label>
					<input type="text" class="form-control m-input" disabled="disabled" name="name" v-model="item_update.name">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Stock Code
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="sku" v-model="item_update.sku">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Unit
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="unit" v-model="item_update.unit">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Quantity
					</label>
					<input type="number" class="form-control m-input" step="any" name="qty" data-validation-allowing="float" data-validation="required" v-model="item_update.qty">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Purpose
					</label>
					<textarea class="form-control m-input" name="purpose" data-validation="required" rows="3" v-model="item_update.purpose"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit btnUpdate">Update</button>
				<button type="button" class="btn btn-success btnCancel" data-dismiss="modal">Print Preview</button>
			</div>
			</form>
		</div>
	</div>
</div>
<!-- Model Item Lookup End -->

<script type="text/javascript">
var _modalItemEdit = $("#modal-item-update_lookup");
var _issuanceReceiver = [];
var _issuanceChargedTo = [];
<?php if(isset($issuanceReceiver) && $issuanceReceiver): ?>
_issuanceReceiver = <?php echo json_encode($issuanceReceiver); ?>;
<?php endif; ?>
<?php if(isset($issuanceChargedTo) && $issuanceChargedTo): ?>
_issuanceChargedTo = <?php echo json_encode($issuanceChargedTo); ?>;
<?php endif; ?>
<?php if(isset($approvedBy) && $approvedBy): ?>
_issuanceApprovedBy = <?php echo json_encode($approvedBy); ?>;
<?php endif; ?>

var _dtissuance_contents = $("#table-issuance-contents").DataTable({
	dom: '<"toolbar">rt',
	serverSide: true,
	processing: true,
	ajax: {
	url: "<?php echo base_url("issuance/get_issuance_content_temp"); ?>",
		type: "post",
		dataType: "json",
	}, columnDefs: [
		{ targets: [-1], orderable: false }
	],
});
$("div.toolbar").css({ "margin-bottom": "5px" });
$("div.toolbar").html('<button type="button" class="m-portlet__nav-link btn m-btn--square btn-success btnNew"  data-toggle="modal" data-target="#modal-item-lookup"><i class="fa fa-plus"></i> Add Item </button>');

// add issuance validate
$.validate({
	form : '#add_issuance_form',
	lang: 'en',
	onSuccess : function(form) {
		
		var countRows = _dtissuance_contents.rows()[0].length;
		if(countRows > 0){
			$.ajax({
				url: form[0].action,
				type: "POST",
				dataType: "json",
				data: $("#add_issuance_form").find("input,select").serialize(),
				beforeSend: function(){
					$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
				},
				success: function(data){
					if(data.status){
						toastr.success(data.toastr_msg, "Item has been added", 5000);
						window.open("<?php echo site_url("inventory/printable/print_issuance"); ?>"+"/"+data.id, "_blank");
						setTimeout(function(){ window.location.href = "<?php echo site_url('issuance/index'); ?>"; }, 1000);
					}else{
						toastr.error(data.toastr_msg, "Error inventory item", 5000);
					}
					$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
				} 
			});
		}
		else{
			toastr.error("No item(s) found, please add items to proceed!", "Error Issuance", 5000);
		}
		
		return false;
	},
});

	//select init
$('#item-collection').select2();
$('#item-collection_update').select2();

	//select2 on select event
$('#item-collection').on('select2:select', function (e) {
	var data = e.params.data;
	$.ajax({
		url: "<?php echo site_url('issuance/get_item_data'); ?>",
		type: "POST",
		dataType: "json",
		data: {id : data.id},
		success: function(json){
			$("form#form-item-new input[name=name]").val(json.name);
			$("form#form-item-new input[name=sku]").val(json.sku);
			$("form#form-item-new input[name=unit]").val(json.uom_code);
			
			if(typeof json.pop_message !== "undefined"){
				toastr.error(json.pop_message);
			}
		}
	});
});

$('#item-collection_update').on('select2:select', function (e) {
	var data = e.params.data;
	$.ajax({
		url: "<?php echo site_url('issuance/get_item_data'); ?>",
		type: "POST",
		data: {id : data.id},
		success: function(data){
			$("form#form-item-update input[name=name]").val(data.name);
			$("form#form-item-update input[name=sku]").val(data.sku);
			$("form#form-item-update input[name=unit]").val(data.uom_code);
		}
	});
});

	// add item validate
$.validate({
	form : '#form-item-new',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			dataType: "json",
			data: $("#form-item-new").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(data){
				if(data.response){
					toastr.success(data.toastr_msg, "Item has been added", 5000);
				}else{
					toastr.error(data.toastr_msg, "Error inventory item", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
				_dtissuance_contents.ajax.reload();
				$("#form-item-new").trigger("reset");
				$("#item-collection").val('').trigger('change');
			}
		});
		return false;
	},
});

	//remove item content temp
$("#table-issuance-contents").on("click",".btnRemoveItem",function(){
	var id = $(this).attr("data-id");

	$.ajax({
		url: "<?php echo site_url('issuance/remove_item_content_temp');?>",
		type: "POST",
		dataType: "json",
		data: { id : id},
		success: function(data){
			if(data.status){
				toastr.success(data.toastr_msg, "Item has been removed.", 5000);
				_dtissuance_contents.ajax.reload();
			}else{
				toastr.error(data.toastr_msg, "Error inventory item", 5000);
			}
		}
	});
});

jQuery(document).on("click", ".btn-cancel_transaction", function(){
	window.location.href = "<?php echo site_url("issuance/index"); ?>";
});
	
var dtPicker = $('#m_datetimepicker-issued_date').datetimepicker({
	todayHighlight: true,
	autoclose: true,
	format: 'mm/dd/yyyy hh:ii',
	defaultDate: moment().format("MM/dd/YYYY HH:ii"),
});
$('#m_datetimepicker-issued_date').val(moment().format("MM/DD/YYYY HH:mm"));
	
var _items = { id: 0, name: "", sku: "", unit: "", qty: 0, purpose: "" };
var vm = new Vue({
	el: "#form-item-update",
	data: {	item_update: _items },
	mounted: function(){
		$.validate({
			form : '#form-item-update',
			lang: 'en',
			onSuccess : function(form) {
				var _url = form[0].action;
				var _data = jQuery(form[0]).serialize();
				var _btnSubmit = $(form[0]).find(".btn-submit");
				
				$.ajax({
					url: _url,
					type: "POST",
					data: _data,
					beforeSend: function(){
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					},
					success: function(data){
						if(data.response){
							toastr.success(data.toastr_msg, "Item has been updated", 5000);
							_modalItemEdit.modal("hide");
							setTimeout(function(){ _dtissuance_contents.ajax.reload(); }, 500);
						}else{
							toastr.error(data.toastr_msg, "Error item update", 5000);
						}
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					}
				});
				
				return false;
			}
		});
	}
});

jQuery(document).on("click", ".btnEditItem", function(){
	var dataId = $(this).data("id");
	$.ajax({
		url: "<?php echo site_url("issuance/get_issuance_row_content"); ?>",
		type: "post",
		dataType: "json",
		data: { id: dataId },
		success: function(json){
			if(json.response){
				vm.item_update = json.value;
				_modalItemEdit.modal("show");
			}
		}
	});
});


$(document).ready(function(){
	//init select2
	$("#select2Contractor").select2({ placeholder: "Select a contractor", width: "100%" });
	$("#item-collection").select2({ placeholder: "Select Item"});
	issuanceTypeHead();
});

var issuanceTypeHead = function() {
	var substringMatcher = function(strs) {
		return function findMatches(q, cb) {
			var matches, substringRegex;
			matches = [];
			substrRegex = new RegExp(q, 'i');
			$.each(strs, function(i, str) {
				if (substrRegex.test(str)) {
					matches.push(str);
				}
			});

			cb(matches);
		};
	};

	$('#m_typeahead_1').typeahead({
		hint: false,
		highlight: true,
		minLength: 1
	}, {
		name: 'received_by',
		source: substringMatcher(_issuanceReceiver)
	});
	
	$('#m_typeahead_2').typeahead({
		hint: false,
		highlight: true,
		minLength: 1
	}, {
		name: 'charge_to',
		source: substringMatcher(_issuanceChargedTo)
	});

	$('#m_typeahead_3').typeahead({
		hint: false,
		highlight: true,
		minLength: 1
	}, {
		name: 'approved_by',
		source: substringMatcher(_issuanceApprovedBy)
	});
}
</script>
<style>
.tt-menu { width: 100%; }
</style>