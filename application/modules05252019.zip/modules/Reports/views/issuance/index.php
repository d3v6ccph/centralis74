<style type="text/css">.redClass{background: #ff8888 !important;}</style>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Issuance Report
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item"></li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-issuance_report" style="width:100%;">
								<thead>
									<tr>
										<th>REF</th>
										<th>STOCK CODE</th>
										<th>ISSUED TO</th>
										<th>ITEM</th>
										<th>UNIT</th>
										<th>QTY</th>
										<th>DATE ISSUED</th>
										<th>APPROVED BY</th>
										<th>PURPOSE</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Search Issuance Data :: Start -->
<div class="modal fade" id="m_daterangepicker_modal" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="">
					Search Issuance Data
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true" class="la la-remove"></span>
				</button>
			</div>
			<form class="m-form m-form--fit m-form--label-align-right"  id="form_searchdate" action="<?php echo site_url("reports/issuance_data")?>" method="POST">
				<div class="modal-body">
					<div class="form-group">
						<label class="form-control-label">Select Contractor</label><br>
						<select class="form-control m-select2 col-md-12" id="contractor_select2" name="contractor">
							<option selected="selected" disabled="disabled">Search Contractor</option>
							<?php 
							$contractorCollection = $this->contractors_model->getContractorsName();

								if($contractorCollection){
									foreach($contractorCollection->result_array() as $_contractorCollection){
										echo "<option value='{$_contractorCollection["id"]}'>{$_contractorCollection["name"]}</option>";
									}
								}
							?>
						</select>
					</div>
					<div class="form-group">
						<label class="form-control-label">Select Date Range</label>
						<input type="text" name="daterange" class="form-control" data-validation="required" id="m_daterangepicker_1_modal" readonly="" placeholder="Select time">
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-secondary m-btn" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-brand m-btn btnAdvance_search" onclick="searchrange()">
						Search
					</button>
				</div>
			</form>
		</div>
	</div>
</div>


<!-- Search Attendance Data :: End -->
<script type="text/javascript">
m_startDate = "";
m_endDate = "";
var	x = {};
// init daterange picker 
$('#m_daterangepicker_1_modal').daterangepicker({
	buttonClasses: 'm-btn btn',
	applyClass: 'btn-primary',
	cancelClass: 'btn-secondary'
});

var	startDate = $("#m_daterangepicker_1_modal").data('daterangepicker').startDate;
var	endDate = $("#m_daterangepicker_1_modal").data('daterangepicker').endDate;

var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";

$('#m_daterangepicker_1_modal').on('apply.daterangepicker', function(ev, picker) {
  m_startDate = picker.startDate.format('MMMM DD, YYYY');
  m_endDate = picker.endDate.format('MMMM DD, YYYY');

  // console.log(m_startDate);
  // console.log(m_endDate);
});


var _dtTable = $("#table-issuance_report").DataTable({
	dom: 'B<"#irToolbar.toolbar">frtlip',
	serverSide: false,
	processing: false,
	ajax: {
		url: "<?php echo base_url("Reports/issuance_data"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "reference_no"},
		{ data: "sku"},
		{ data: "contractor_name"},
		{ data: "name"},
		{ data: "uom_code"},
		{ data: "qty",className: "text-center"},
		{ data: "issued_date"},
		{ data: "approved_by"},
		{ data: "purpose", render: function (data, type, row) { if(row.status == 0){return row.cancel_remarks; }else{return row.purpose;} }},
	], 
	pageLength: 0,
	paging: false,
	lengthMenu: [ [10, 20, 50, 100, 200, 500, -1], [10, 20, 50, 100, 200, 500, 'ALL'] ],
	createdRow: function (row, data, index) {
        if(data.status === "0"){$(row).addClass("redClass");}
    },
	buttons: [
      {
          extend: 'pdfHtml5',
		  customize: function (win) {
		  	/**adjust table width**/
			  	// var colCount = new Array();
	     //        $("#table-issuance_report").find('tbody tr:first-child td').each(function(){
	     //            if($(this).attr('colspan')){
	     //                for(var i=1;i<=$(this).attr('colspan');$i++){
	     //                    colCount.push('*');
	     //                }
	     //            }else{ colCount.push('*'); }
	     //        });
	     //        win.content[1].table.widths = colCount;

	        //hightlight cancelled item
	         win.content[1].table.widths = ["8%","8%","12%","18%","5%","9%","8%","10%","22%",];

		    var tblBody = win.content[1].table.body;
		    $("#table-issuance_report").find('tr').each(function (ix, row) {
		    	var index = ix;
				var rowElt = row;
	    		if ($(this).hasClass("redClass")) {
			    	$(rowElt).find('td').each(function (ind, elt) {
	                    win.content[1].table.body[index][ind].fillColor = "#ff8888";
	                   var str = win.content[1].table.body[index][ind].text;
	                   win.content[1].table.body[index][ind].text = str.toUpperCase();
			   		});
            	}
            	$(rowElt).find('td').each(function (ind, elt) {
	                   var str = win.content[1].table.body[index][ind].text;
	                   win.content[1].table.body[index][ind].text = str.toUpperCase();
			   		});
		    });

		    // center col values
		    var rowCount = win.content[1].table.body.length;
			for (i = 1; i < rowCount; i++) {
				win.content[1].table.body[i][5].alignment = 'center';
			}

		    win.content[1].table.body[0][0].alignment = 'left';
		    win.content[1].table.body[0][1].alignment = 'left';
		    win.content[1].table.body[0][2].alignment = 'left';
		    win.content[1].table.body[0][3].alignment = 'left';
		    win.content[1].table.body[0][4].alignment = 'left';
		    win.content[1].table.body[0][5].alignment = 'center';
		    win.content[1].table.body[0][6].alignment = 'left';
		    win.content[1].table.body[0][7].alignment = 'left';
		    win.content[1].table.body[0][8].alignment = 'left';

		  },
          title: function(){
          	return "Issuance Report as of "+ m_startDate + " to " + m_endDate;
          },
          orientation: 'landscape',
          pageSize: 'LEGAL',
		  className: 'btnPdfAction',
		  filename: function(){
            return "Issuance Report as of "+ m_startDate + " to " + m_endDate;
        },
      },{
        extend: 'excel',
        customize: function (win) {

        	console.log(win);
		  	/**adjust table width**/

		  //   var tblBody = win.content[1].table.body;
		  //   $("#table-issuance_report").find('tr').each(function (ix, row) {
		  //   	var index = ix;
				// var rowElt = row;
	   //  		if ($(this).hasClass("redClass")) {
			 //    	$(rowElt).find('td').each(function (ind, elt) {
	   //                  win.content[1].table.body[index][ind].fillColor = "#ff8888";
			 //   		});
    //         	}
		  //   });

		    // win.content[1].table.body[0][0].alignment = 'left';
		    // win.content[1].table.body[0][1].alignment = 'left';
		    // win.content[1].table.body[0][2].alignment = 'left';
		    // win.content[1].table.body[0][3].alignment = 'left';
		    // win.content[1].table.body[0][4].alignment = 'left';
		    // win.content[1].table.body[0][5].alignment = 'left';
		    // win.content[1].table.body[0][6].alignment = 'left';
		    // win.content[1].table.body[0][7].alignment = 'left';

		},
        title: function(){
        	return "Issuance Report as of "+ m_startDate + " to " + m_endDate;
       },
		className: 'btnExcelAction',
		filename: function(){
            return "Issuance Report as of "+ m_startDate + " to " + m_endDate;
        },
    },
  ],
	  initComplete: function(settings, json){
		$(".btnPdfAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".btnExcelAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".dt-buttons").appendTo("div#irToolbar");
		$("div.toolbar .dt-buttons").prepend('<button type="button" id="issuance_report-search" class="m-portlet__nav-link btn m-btn--square btn-primary btnAdvance_search"  data-toggle="modal" data-target="#m_daterangepicker_modal"><i class="fa fa-search"></i> Advance Search</button>');
		btnAction();
	}
});


var searchrange = function(){
	var form_searchdate = $("#form_searchdate");
	$.ajax({
		url: form_searchdate.attr("action"),
		type: "POST",
		dataType: "json",
		data: form_searchdate.serialize(),
		beforeSend: function()
		{
			mApp.blockPage({
				overlayColor: '#000000',
				type: 'loader',
				state: 'primary',
				message: 'Please wait...',
			});

			$(".blockUI.blockMsg .m-blockui").removeAttr("style");
			$(".blockUI.blockMsg.blockPage").css("z-index","2000");


		},
		success: function(json){
			_dtTable.clear();
			_dtTable.rows.add(json.data).draw();
			btnAction();
			$('#m_daterangepicker_modal').modal('hide');
			mApp.unblockPage();

		}
	});
}

//init select2 contractor
 $('#contractor_select2').select2({width: "100%"});

function btnAction(){
	var dtCount = _dtTable.data().count();

	if(dtCount == 0){
		$(".buttons-pdf").attr("disabled","disabled");
		$(".buttons-excel").attr("disabled","disabled");
	}else{
		$(".buttons-pdf").removeAttr("disabled");
		$(".buttons-excel").removeAttr("disabled");
	}
}

</script>