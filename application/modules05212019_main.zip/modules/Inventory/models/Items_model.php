<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Items_model extends CI_Model{
	protected $itemsTable = "items";
	protected $uomTable = "uom";
	
	function __construct(){
		parent::__construct();
		$this->load->model("access_control_model", "acl_model");
		$this->load->model("datatable_model","dt_model");
	}
	
	function addInventoryItems(){
		$post = $this->input->post();
		if($post){
			$checksku = $this->checkInventoryCode($post);
			if($checksku){
				if(!isset($post["sku"])){ $post["sku"] = $this->core_layout->generateCode(); }
				
				$session = $this->core_layout->getCurrentSession();
				$post["created_by"] = $session["emp_id"];
				
				$insert = $this->db->insert($this->itemsTable, $post);
				if($insert){
					$result["response"] = true; 
					$result["toastr_msg"] = "Iventory Item has been saved.";
				}else{
					$result["response"] = false;
					$result["toastr_msg"] = "Error in saving iventory item!";
				}
			}else{
				$result["response"] = false;
				$result["toastr_msg"] = "Iventory Item code already exist!";
			}
		}else{
			$result["response"] = false;
			$result["toastr_msg"] = "No available data for saving!";
		}
		
		return $result;
	}
	
	function getInventoryItemData(){
		$post = $this->input->post();
		$resultset = array();
		if(isset($post["id"]) && $post["id"]){
			$query = $this->db->get_where($this->itemsTable, $post);
			if($query->num_rows() == 1){
				$resultset["response"] = true;
				$resultset["value"] = $query->row_array();
			}else{
				$resultset["response"] = false;
			}
		}else{
			$resultset["response"] = false;
		}
		return $resultset;
	}
	
	function updateInventoryItems(){
		$post = $this->input->post();
		$result = array();
		if(isset($post["id"]) && $post["id"]){
			$id = $post["id"];
			unset($post["id"]);
			
			$session = $this->core_layout->getCurrentSession();
			$post["updated_by"] = $session["emp_id"];
			$post["updated_at"] = date("Y-m-d H:i:s");
			
			$update = $this->db->update($this->itemsTable, $post, array("id"=>$id));
			if($update){
				$result["response"] = true; 
				$result["toastr_msg"] = "Iventory item has been updated.";
			}else{
				$result["response"] = false;
				$result["toastr_msg"] = "Error in updating inventory item!";
			}
		}else{
			$result["response"] = false;
			$result["toastr_msg"] = "No available data for saving!";
		}
		
		return $result;
	}
	
	function removeInventoryItem(){
		$post = $this->input->post();
		$result = array();
		if(isset($post["id"]) && $post["id"]){
			$this->db->delete($this->itemsTable, array('id'=>$post['id']));
			if (!$this->db->affected_rows()) {
				$result["response"] = false;
				$result["toastr_msg"] = "Error! ID [{$post['id']}] not found";
			} else {
				$result["response"] = true;
				$result["toastr_msg"] = "Inventory item has been removed.";
			}
		}else{
			$result["response"] = false;
			$result["toastr_msg"] = "No available data for removal!";
		}
		
		return $result;
	}
	
	function getItemsList(){
		$post = $this->input->post();
		if($post){
			$columns = array("items.id", "items.sku", "items.qty", "items.name", "uom.uom_desc", "items.reorder_qty", "items.beginning_qty");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable($this->itemsTable);
			$dtInventoryItems->setTableAlias("items");
			
			$dtInventoryItems->setParameterFields($columns);
			
			$joinTable = array();
			$joinTable["table"][$this->uomTable] = "uom";
			$joinTable["fields"][] = "uom.id=items.unit";
			$joinTable["field_loc"][] = "LEFT";
			
			$dtInventoryItems->setJoinTable($joinTable);
			$dtInventoryItems->setWhereInField("items.id");
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$qty = $pst->qty;
					$beginning_qty = $pst->beginning_qty;
					
					$totalQty = $qty + $beginning_qty;
					$totalQty = (is_float($totalQty))? number_format($totalQty, 2, ".", ","): number_format(intval($totalQty), 0, "", ",");
					
					$totalBegQty = (is_float($pst->beginning_qty))? number_format($pst->beginning_qty, 2, ".", ","): number_format(intval($pst->beginning_qty), 0, "", ",");
					$totalReorderQty = (is_float($pst->reorder_qty))? number_format($pst->reorder_qty, 2, ".", ","): number_format(intval($pst->reorder_qty), 0, "", ",");
					
					$nestedData['id'] = $pst->id;
					$nestedData['sku'] = $pst->sku;
					$nestedData['name'] = $pst->name;
					$nestedData['uom_desc'] = $pst->uom_desc;
					$nestedData['qty'] = $totalQty;
					$nestedData['reorder_qty'] = $totalReorderQty;
					$nestedData['beginning_qty'] = $totalBegQty;
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data" => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}
	
	private function checkInventoryCode($data=array()){
		if($data){
			$query = $this->db->get_where($this->itemsTable, array("sku"=>$data["sku"]));
			if($query->num_rows() == 0){ return true; }else{ return false; }
		}else{ return false; }
	}
	
	private function checkInventoryCode_oldcode($data=array()){
		$response = array(
		  'valid' => false,
		  'message' => 'SKU already exist.'
		);

		if($data){
			$query = $this->db->get_where($this->itemsTable, array("sku"=>$data["sku"]));
			if($query->num_rows() == 0){
				$response = array(
				  'valid' => true,
				);
			}else{
				$response = array(
				  'valid' => false,
				  'message' => 'SKU already exist.'
				);
			}
		}else{
			$response = array(
			  'valid' => false,
			  'message' => 'SKU already exist.'
			);
		}

		return $response;
	}

	function getIssuanceItems(){
		$post = $this->input->post();
		
		if(isset($post["daterange"])){
			$dates = explode(" - ", $post["daterange"]);
			if(isset($post['contractor'])){
				$query = $this->db->query("SELECT issuance.id,issuance.reference_no,contractors.name as contractor_name,contractors.id,issuance.issued_to,DATE_FORMAT(issuance.issued_date, '%M %d, %Y') as issued_date, issuance_contents.item,issuance_contents.qty,issuance_contents.purpose,items.name,items.sku,items.id,items.unit,uom.uom_code FROM ((issuance LEFT JOIN issuance_contents ON issuance.id = issuance_contents.issuance_id) LEFT JOIN items ON issuance_contents.item = items.id) LEFT JOIN uom ON items.unit = uom.id LEFT JOIN contractors ON contractors.id = issuance.issued_to WHERE (DATE_FORMAT(issuance.issued_date,'%m/%d/%Y') BETWEEN '".$dates[0]."' AND '".$dates[1]."') AND issuance.issued_to = ".$post['contractor']);
			}else{
				$query = $this->db->query("SELECT issuance.id,issuance.reference_no,contractors.name as contractor_name,contractors.id,issuance.issued_to,DATE_FORMAT(issuance.issued_date, '%M %d, %Y') as issued_date, issuance_contents.item,issuance_contents.qty,issuance_contents.purpose,items.name,items.sku,items.id,items.unit,uom.uom_code FROM ((issuance LEFT JOIN issuance_contents ON issuance.id = issuance_contents.issuance_id) LEFT JOIN items ON issuance_contents.item = items.id) LEFT JOIN uom ON items.unit = uom.id LEFT JOIN contractors ON contractors.id = issuance.issued_to WHERE (DATE_FORMAT(issuance.issued_date,'%m/%d/%Y') BETWEEN '".$dates[0]."' AND '".$dates[1]."')");
			}
			return array("data"=>$query->result_array());
		}else{
			return array("data"=>array());
		}
	}

	function getReceiveItems(){
		$post = $this->input->post();

		if(isset($post["daterange"])){
			$dates = explode(" - ", $post["daterange"]);
			$query = $this->db->query("SELECT receiving.id,receiving.reference_no, DATE_FORMAT(receiving.received_date, '%M %d, %Y') as received_date, receiving_contents.item,receiving_contents.qty,items.name,items.sku,items.id,items.unit,uom.uom_code FROM ((receiving LEFT JOIN receiving_contents ON receiving.id = receiving_contents.receiving_id) LEFT JOIN items ON receiving_contents.item = items.id) LEFT JOIN uom ON items.unit = uom.id WHERE DATE_FORMAT(receiving.received_date,'%m/%d/%Y') BETWEEN '".$dates[0]."' AND '".$dates[1]."'");
			return array("data"=>$query->result_array());
		}else{
			return array("data"=>array());
		}
	}

	function getInventoryData(){
		$post = $this->input->post();
		$resultset = array();

		$getStockCollection = $this->db->query("SELECT items.id, items.name, items.sku, uom.uom_code, IFNULL((SELECT SUM(qty) from receiving_contents WHERE receiving_contents.item = items.id),0) AS inventoryIn,IFNULL((SELECT SUM(qty) from issuance_contents WHERE issuance_contents.item = items.id),0) AS inventoryOut, (IFNULL((SELECT SUM(qty) from receiving_contents WHERE receiving_contents.item = items.id),0) - IFNULL((SELECT SUM(qty) from issuance_contents WHERE issuance_contents.item = items.id),0)) AS balance FROM items LEFT JOIN uom ON items.unit=uom.id LEFT JOIN issuance_contents ON issuance_contents.item = items.id LEFT JOIN receiving_contents ON receiving_contents.item = items.id GROUP BY items.sku");
		$data = array();
		if($getStockCollection->num_rows() > 0){
			foreach($getStockCollection->result() as $rs){
				$rs->inventoryIn = is_float(floatval($rs->inventoryIn))? number_format(floatval($rs->inventoryIn), 2, ".", ","): number_format($rs->inventoryIn, 0, "", ",");
				$rs->inventoryOut = is_float(floatval($rs->inventoryOut))? number_format(floatval($rs->inventoryOut), 2, ".", ","): number_format($rs->inventoryOut, 0, "", ",");
				$rs->balance = is_float(floatval($rs->balance))? number_format(floatval($rs->balance), 2, ".", ","): number_format($rs->balance, 0, "", ",");
				$data[] = $rs;
			}
		}
		$resultset["data"] = $data;
		return $resultset;
	}
	
	function select2GetCurrentItems(){
		$post = $this->input->post();
		
		$resultset = array();
		$this->db->select("id, CONCAT(sku, ' | ', name) as text");
		$this->db->from($this->itemsTable);
		if(isset($post["term"]) && $post["term"]){
			$this->db->like("sku", $post["term"], "both");
			$this->db->or_like("name", $post["term"], "both");
		}
		$query = $this->db->get();
		
		if($query->num_rows() > 0){ $resultset["results"] = $query->result_array(); }
		else{ $resultset["results"] = array(); }
		
		return $resultset;
	}

	function getSearchedItem(){
		$resultset = array();
		$post = $this->input->post();
		if($post){
			$query = $this->db->get_where($this->itemsTable, $post);
			if($query->num_rows() == 1){
				$row = $query->row();
				$row->current_qty = $row->reorder_qty;
				$input = "";
				$input .= "<div class='form-group m-form__group row'>";
				$input .= "<input type='number' name='needed_qty[{$row->id}]' value='0' class='form-control' style='padding-top: 0; padding-bottom: 0;' />";
				$input .= "</div>";
				$row->needed_qty = $input;
				$row->action = "<button class='btn btn-danger btn-sm btnRemoveRow'><i class='fa fa-trash'></i></button>";
				$resultset["data"] = $row;
			}
		}
		
		return $resultset;
	}
	
	function getSearchedItemBq(){
		$resultset = array();
		$post = $this->input->post();
		if($post){
			$query = $this->db->get_where($this->itemsTable, $post);
			if($query->num_rows() == 1){
				$row = $query->row();
				$row->current_qty = $row->beginning_qty;
				$input = "";
				$input .= "<div class='form-group m-form__group row'>";
				$input .= "<input type='number' name='needed_qty[{$row->id}]' value='0' class='form-control' style='padding-top: 0; padding-bottom: 0;' />";
				$input .= "</div>";
				$row->needed_qty = $input;
				$row->action = "<button class='btn btn-danger btn-sm btnRemoveRow'><i class='fa fa-trash'></i></button>";
				$resultset["data"] = $row;
			}
		}
		
		return $resultset;
	}
	
	function setReorderedItems(){
		$resultset = array();
		$post = $this->input->post();
		if(isset($post["needed_qty"]) && $post["needed_qty"]){
			$hasUpdates = false;
			foreach($post["needed_qty"] as $id => $value){
				$where = array();
				$where["id"] = $id;
				
				$data = array();
				$data["reorder_qty"] = $value;
				
				$update = $this->db->update($this->itemsTable, $data, $where);
				if($update){
					$hasUpdates = true;
				}
			}
			
			if($hasUpdates){
				$resultset["response"] = true;
			}else{
				$resultset["response"] = false;
			}
		}else{
			$resultset["response"] = false;
		}
		
		return $resultset;
	}
	function setBeginningItems(){
		$resultset = array();
		$post = $this->input->post();
		if(isset($post["needed_qty"]) && $post["needed_qty"]){
			$hasUpdates = false;
			foreach($post["needed_qty"] as $id => $value){
				$where = array();
				$where["id"] = $id;
				
				$data = array();
				$data["beginning_qty"] = $value;
				
				$update = $this->db->update($this->itemsTable, $data, $where);
				if($update){
					$hasUpdates = true;
				}
			}
			
			if($hasUpdates){
				$resultset["response"] = true;
			}else{
				$resultset["response"] = false;
			}
		}else{
			$resultset["response"] = false;
		}
		
		return $resultset;
	}
}