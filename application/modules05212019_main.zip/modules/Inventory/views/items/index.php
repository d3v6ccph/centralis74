<?php $actions = $this->core_layout->getCurrentActions(); ?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Inventory - Stocks
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								<div class="btn-group m-btn-group" role="group">
									<button type="button"class="m-btn btn btn-secondary btnUpload" data-toggle="modal" data-target="#modal_fileupload">
										<i class="fa fa-upload"></i>
										Import
									</button>
									<button type="button"class="m-btn btn btn-secondary btnNew" data-toggle="modal" data-target="#modal-reorder_qty">
										<i class="fa fa-cart-plus"></i>
										Re-order Qty
									</button>
									<button type="button"class="m-btn btn btn-secondary btnNew" data-toggle="modal" data-target="#modal-beginning_qty">
										<i class="fa fa-plus"></i>
										Beg. Balance
									</button>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-inventory_item" width="100%">
								<thead>
									<tr>
										<th>Stock Code</th>
										<th>Item Description</th>
										<th>Unit</th>
										<th>Qty</th>
										<th>Beg. Balance</th>
										<th>Re-order Qty</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
			<!--end::Portlet-->
		</div>
	</div>
</div>
<div class="modal fade" id="modal-inventory_item-new" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('inventory/add_item'); ?>" method="POST" id="form-item-new">
			<div class="modal-header"><h5 class="modal-title">New Item</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">Stock Code</label>
					<input type="text" name="sku" class="form-control" data-validation="required" >
				</div>
				<div class="form-group">
					<label class="form-control-label">Item Description</label>
					<input type="text" name="name" class="form-control" data-validation="required">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Unit
					</label>
					<select class="form-control" tabindex="-1" data-validation="required" aria-hidden="true" name="unit" style="width: 100% !important;" id="unit-collection">
						<option disabled="disabled" selected="selected" value="">Select Unit</option>
						<?php
							$unitCollection = $this->crud->getCollection(array(),"uom");
							if($unitCollection):
								foreach($unitCollection as $_unitCollection):
									?>
										<option value="<?php echo $_unitCollection["id"]?>"><?php echo $_unitCollection["uom_code"]?></option>
									<?php
								endforeach; 
							endif;
						?>
					</select>
				</div>
				<div class="form-group">
					<label class="form-control-label">Re-order Quantity Level</label>
					<input type="number" id="nReorderQty" name="reorder_qty" class="form-control" data-validation="required" value="0">
				</div>
				<div class="form-group">
					<label class="form-control-label">Beginning Balance Quantity</label>
					<input type="number" id="nBeginningQty" name="beginning_qty" class="form-control" data-validation="required" value="0">
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit btnSave">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-inventory_item-edit" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('inventory/update_items'); ?>" method="POST" id="form-item-edit">
			<input type="hidden" class="inptId" name="id" v-model="item_update.id" />
			<div class="modal-header">
				<h5 class="modal-title" >Update Item</h5>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">Item Description</label>
					<input type="text" name="name" class="form-control" data-validation="required" v-model="item_update.name">
				</div>
				<div class="form-group">
					<label class="form-control-label">Stock Code</label>
					<input type="text" name="sku" class="form-control" data-validation="required" v-model="item_update.sku">
				</div>
				<div class="form-group">
					<label class="form-control-label">
						Unit
					</label>
					<select class="form-control" tabindex="-1" data-validation="required" aria-hidden="true" name="unit" style="width: 100% !important;" id="unit-collection" v-model="item_update.unit">
						<option disabled="disabled" selected="selected" value="">Select Unit</option>
						<?php
							$unitCollection = $this->crud->getCollection(array(), "uom");
							if($unitCollection):
								foreach($unitCollection as $_unitCollection):
									?>
										<option value="<?php echo $_unitCollection["id"]; ?>"><?php echo $_unitCollection["uom_code"]; ?></option>
									<?php
								endforeach; 
							endif;
						?>
					</select>
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit btnUpdate">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-reorder_qty" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Set Item <small>Re-order Quantity</small></h5>
			</div>
			<div class="modal-body">
				<div class="form-group m-form__group row">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-12">Search Item</label>
					<div class="col-lg-8 col-md-8 col-sm-12">
						<select class="form-control m-select2" id="search_item" name="search_item" aria-hidden="true"></select>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-12">
						<button type="button" class="btn btn-secondary btnNew btnAddItemToList"><i class="fa fa-plus"></i></button>
					</div>
				</div>
				<form id="frm-reorder_qty">
				<table class="table table-striped table-bordered" id="table-reorder_qty" style="width: 100%;">
					<col width="20%">
					<col width="35%">
					<col width="20%">
					<col width="20%">
					<col width="5%">
					<thead>
						<tr>
							<th>Stock Code</th>
							<th>Item Description</th>
							<th>Current Re-order</th>
							<th>Needed Re-order</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
				</form>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit_reorder btnUpdate">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-beginning_qty" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Set Item <small>Beginning Quantity</small></h5>
			</div>
			<div class="modal-body">
				<div class="form-group m-form__group row">
					<label class="col-form-label col-lg-2 col-md-2 col-sm-12">Search Item</label>
					<div class="col-lg-8 col-md-8 col-sm-12">
						<select class="form-control m-select2" id="search_item_bq" name="search_item" aria-hidden="true"></select>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-12">
						<button type="button" class="btn btn-secondary btnNew btnAddItemBQToList"><i class="fa fa-plus"></i></button>
					</div>
				</div>
				<form id="frm-beginning_qty">
				<table class="table table-striped table-bordered" id="table-beginning_qty" style="width: 100%;">
					<col width="20%">
					<col width="35%">
					<col width="20%">
					<col width="20%">
					<col width="5%">
					<thead>
						<tr>
							<th>Stock Code</th>
							<th>Item Description</th>
							<th>Current Beg. Balance</th>
							<th>Needed Beg. Balance</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
				</form>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit_bq btnUpdate">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-inventory_item-delete" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<input type="hidden" id="removeItem" value="0" />
			<div class="modal-header">
				<h5 class="modal-title">Delete Item</h5>
			</div>
			<div class="modal-body"><i class="la la-warning"></i>  Are you sure you want to delete this item? </div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit-delete btnDelete">Delete</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_import" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form name="uploadForm" id="uploadForm" action="<?php echo site_url("inventory/moveUploadedFile")?>" method="POST" enctype="multipart/form-data">
				<div class="modal-header">
					<h5 class="modal-title">Upload</h5>
				</div>
				<div class="modal-body">
					<div class="form-group m-form__group">
						<label>
							File Browser
						</label>
							<input type="file" name="file">
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary btnNew btn-submit">Upload</button>
					<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_fileupload" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Upload</h5>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-md-4">
						<span class="btn btn-success fileinput-button">
							<i class="glyphicon glyphicon-plus"></i>
							<span>Select CSV File</span>
							<!-- The file input field used as target for the file upload widget -->
							<input id="fileupload" type="file" name="files[]" />
						</span>
					</div>
					<div class="col-md-8">
						<div id="progress" class="progress" style="display: none; margin: 2% 0%;">
							<div class="progress-bar progress-bar-success"></div>
						</div>
					</div>
				</div>
				<!-- The global progress bar -->
				<!-- The container for the uploaded files -->
				<br>
				<div class="row">
					<div class="col-md-12">
						<div id="files" class="files"></div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
var _currentActions = <?php echo json_encode($actions); ?>;
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";

var _tableItem = $("#table-inventory_item");
var _tableReorderQty = $("#table-reorder_qty");
var _tableBeginningQty = $("#table-beginning_qty");

var _modalItem = $("#modal-inventory_item-new");
var _modalItemEdit = $("#modal-inventory_item-edit");
var _modalItemDelete = $("#modal-inventory_item-delete");

var _dtReorderTable = $("#table-reorder_qty").DataTable({
	dom: "t",
	ordering: false,
	columns: [
		{ data: "sku" },
		{ data: "name" },
		{ data: "current_qty", className: "text-center" },
		{ data: "needed_qty", className: "text-center" },
		{ data: "action", className: "text-center" },
	]
});

var _dtBeginningTable = $("#table-beginning_qty").DataTable({
	dom: "t",
	ordering: false,
	columns: [
		{ data: "sku" },
		{ data: "name" },
		{ data: "current_qty", className: "text-center" },
		{ data: "needed_qty", className: "text-center" },
		{ data: "action", className: "text-center" },
	]
});

var _dtTable = $("#table-inventory_item").DataTable({
	dom: '<"toolbar">frtlip',
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("inventory/get_item_list"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash, limit : "All" }
	}, columns: [
		{ data: "sku", width: "10%" },
		{ data: "name", width: "42%" },
		{ data: "uom_desc", width: "10%" },
		{ data: "qty", width: "10%" },
		{ data: "beginning_qty", width: "10%" },
		{ data: "reorder_qty", width: "10%" },
		{ data: null, width: "8%"},
	], columnDefs: [{
		data: null,
		defaultContent: "",
		targets: -1,
		orderable: false,
		render: function ( data, type, row, meta ) { return itemDatatableActions(row.id); },
	}, { 
		targets: "_all", 
		defaultContent: "", 
	}],
	order: [[ 0, "desc" ]],
	initComplete: function(settings, json){
		if(typeof roleActionUpdate == "function"){ roleActionUpdate(); }
	}
});

$("div.toolbar").html('<button type="button" id="inventory_item-new" class="m-portlet__nav-link btn m-btn--square btn-success btnNew" data-toggle="modal" data-target="#modal-inventory_item-new"><i class="fa fa-plus"></i> New </button>');

function itemDatatableActions($id){
	if($id){
		var _actionButton ="";
		if(typeof _currentActions !== "undefined" && jQuery.inArray("edit", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='"+$id+"'><i class='la la-edit'></i></button>";				
		}
		if(typeof _currentActions !== "undefined" && jQuery.inArray("delete", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill btnRemoveItem' data-id='"+$id+"'><i class='la la-trash'></i></button>";				
		}
		return _actionButton;
	}else{ return false; }
}

$.validate({
	form : '#form-item-new',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			data: $("#form-item-new").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(data){
				if(data.response){
					form[0].reset();
					toastr.success(data.toastr_msg, "Added inventory item", 5000);
					//$("#modal-item-new").modal("hide");
					$("#unit-collection").val('').trigger('change');
					$("#form-item-new").trigger("reset");
					setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
				}else{
					toastr.error(data.toastr_msg, "Error inventory item", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");

			}
		});
		return false;
	},
});

//init validate upload form
$.validate({
	form : '#uploadForm',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			data: $("#uploadForm").find("file").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(data){
				if(data.response){
					toastr.success(data.toastr_msg, "Added inventory item", 5000);
				}else{
					toastr.error(data.toastr_msg, "Error inventory item", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");

			}
		});
		return false;
	},
});

jQuery(document).on("click", ".btn-submit_reorder", function(){
	var _formData = $("#frm-reorder_qty").serialize();
	
	$.ajax({
		url: "<?php echo site_url("inventory/set_reorder_items"); ?>",
		type: "post",
		dataType: "json",
		data: _formData,
		success: function(json){
			if(json.response){
				toastr.success("Re-order item(s) has been updated.", "Re-order Quantity");
				_dtReorderTable.clear();
				_dtReorderTable.draw();
				
				$("#modal-reorder_qty").modal("hide");
				$("#search_item").val("").trigger("change");
				setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
			}else{
				toastr.error("Failed to update re-ordered item(s)!", "Re-order Quantity");
			}
		}
	});
});

jQuery(document).on("click", ".btn-submit_bq", function(){
	var _formData = $("#frm-beginning_qty").serialize();
	
	$.ajax({
		url: "<?php echo site_url("inventory/set_beginning_items"); ?>",
		type: "post",
		dataType: "json",
		data: _formData,
		success: function(json){
			if(json.response){
				toastr.success("Beginning item(s) quantity has been updated.", "Beginning Quantity");
				_dtBeginningTable.clear();
				_dtBeginningTable.draw();
				
				$("#modal-beginning_qty").modal("hide");
				$("#search_item_bq").val("").trigger("change");
				setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
			}else{
				toastr.error("Failed to update beginning item(s) quantity!", "Beginning Quantity");
			}
		}
	});
});

jQuery(document).on("click", ".btnEditItem", function(){
	var _dataId = $(this).data("id");
	
	$.ajax({
		url: "<?php echo site_url("inventory/get_inventory_item"); ?>",
		type: "post",
		dataType: "json",
		data: { id: _dataId },
		success: function(json){
			if(json.response){
				vm.item_update = json.value;
				_modalItemEdit.modal("show");
			}else{
				toastr.error(json.toastr_msg, "Error inventory item", 5000);
			}
		}
		
	});	
});

jQuery(document).on("click", "#table-inventory_item .btnRemoveItem", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	var _inptAcl = _modalItemDelete.find("#removeItem");
	if(typeof _inptAcl !== "undefined"){
		_inptAcl.val(dataId);
		$(_modalItemDelete).modal("show");
	}
});
	
jQuery(document).on("click", ".btn-submit-delete", function(){
	var _btnSubmit = jQuery(this);
	var _dataId = jQuery(this).parent(".modal-footer").parent(".modal-content").children("input#removeItem").val();
	if(typeof _dataId !== "undefined"){
		jQuery.ajax({
			url: "<?php echo base_url("inventory/remove_item"); ?>",
			type: "post",
			data: { id: _dataId },
			beforeSend: function(){
				if(typeof _btnSubmit !== "undefined"){
					if(!_btnSubmit.hasClass("m-btn--custom m-loader m-loader--light m-loader--right")){
						_btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right");
					}
				}
			},
			success: function(json){
				if(json.response){
					toastr.success(json.toastr_msg, "Remove iventory item", 5000);
					$(_modalItemDelete).modal("hide");
					setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
				}else{ toastr.error(json.toastr_msg, "Error removing iventory item", 5000); }
				if(typeof _btnSubmit !== "undefined"){
					if(_btnSubmit.hasClass("m-btn--custom m-loader m-loader--light m-loader--right")){
						_btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right");							
					}
				}
			}
		});			
	}
});

$("#inventory_item-new").on("click",function(){
	$("#modal-inventory_item-new").modal("show");
});

var _items = { id: 0, name: "", sku: "", unit: 0 };
var vm = new Vue({
	el: "#form-item-edit",
	data: {	item_update: _items },
	mounted: function(){
		$.validate({
			form : '#form-item-edit',
			lang: 'en',
			onSuccess : function(form) {
				var _url = form[0].action;
				var _data = jQuery(form[0]).serialize();
				var _btnSubmit = $(form[0]).find(".btn-submit");
				
				$.ajax({
					url: _url,
					type: "POST",
					data: _data,
					beforeSend: function(){
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					},
					success: function(data){
						if(data.response){
							toastr.success(data.toastr_msg, "Update iventory item", 5000);
							_modalItemEdit.modal("hide");
							setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
						}else{
							toastr.error(data.toastr_msg, "Error iventory item", 5000);
						}
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					}
				});
				
				return false;
			}
		});
	}
});

jQuery(_tableReorderQty, "tbody").on("click", ".btnRemoveRow", function(){
	var _self = $(this);
	_dtReorderTable.row(_self.parents('tr')).remove().draw();
});

jQuery(_tableBeginningQty, "tbody").on("click", ".btnRemoveRow", function(){
	var _self = $(this);
	_dtBeginningTable.row(_self.parents('tr')).remove().draw();
});

jQuery(document).on("click", ".btnAddItemBQToList", function(){
	var itemId = $("#search_item_bq").val();
	$.ajax({
		url: "<?php echo site_url("inventory/get_searched_item_bq"); ?>",
		type: "post",
		dataType: "json",
		data: { id: itemId },
		success: function(json){
			if(json.data){
				var _draw = true;
				var _rowData = json.data;
				var _dtData = _dtBeginningTable.data();
				
				jQuery.each(_dtData, function(i, v){
					if(v.id == _rowData.id){ _draw = false; }
				});
				
				if(_draw == true){
					_dtBeginningTable.row.add(json.data).draw();
					$("#search_item_bq").val("").trigger("change");					
				} if(_draw == false){
					toastr.error("Selected item already on the list!", "Beginning Quantity");
				}
			}
		}
	});
});

jQuery(document).on("click", ".btnAddItemToList", function(){
	var itemId = $("#search_item").val();
	$.ajax({
		url: "<?php echo site_url("inventory/get_searched_item"); ?>",
		type: "post",
		dataType: "json",
		data: { id: itemId },
		success: function(json){
			if(json.data){
				var _draw = true;
				var _rowData = json.data;
				var _dtData = _dtReorderTable.data();
				
				jQuery.each(_dtData, function(i, v){
					if(v.id == _rowData.id){ _draw = false; }
				});
				
				if(_draw == true){
					_dtReorderTable.row.add(json.data).draw();
					$("#search_item").val("").trigger("change");					
				} if(_draw == false){
					toastr.error("Selected item already on the list!", "Re-order Quantity");
				}
			}
		}
	});
});

jQuery(document).ready(function(){
	$('#unit-collection').select2();
	$('#search_item_bq').select2({
		width: "100%",
		placeholder: "Search Item",
		ajax: {
			url: '<?php echo site_url("inventory/select2_get_current_items"); ?>',
			dataType: "json",
			type: "post",
		},
	});
	$('#search_item').select2({
		width: "100%",
		placeholder: "Search Item",
		ajax: {
			url: '<?php echo site_url("inventory/select2_get_current_items"); ?>',
			dataType: "json",
			type: "post",
		},
  });
});

$(function () {
    'use strict';
    // Change this to the location of your server-side upload handler:
    var url = "<?php echo site_url("core/upload/excel_files"); ?>";
    $('#fileupload').fileupload({
        url: url,
        dataType: 'json',
        done: function (e, data) {
			var result = data.result;
			if(result.response){
				var a_count = result.added_count;
				var e_count = result.existing_count;
				
				$.ajax({
					url: "<?php echo site_url("core/upload/get_loaded_files"); ?>"+"/"+result.filename,
					dataType: "json",
					success: function(json){
						console.log(json);
					}
				});
				$.each(result.files, function (index, file) {
					var uploadContent = "<p class='custom-row'><span>"+file.client_name+"</span>";
					if(typeof e_count !== "undefined"){
						uploadContent += "<span class='m-menu__link-badge pull-right' style='margin-left: 5px;'><span class='m-badge m-badge--danger m-badge--wide'>Existing Items Total "+e_count+"</span></span>";						
					}
					if(typeof a_count !== "undefined"){
						uploadContent += "<span class='m-menu__link-badge pull-right' style='margin-left: 5px;'><span class='m-badge m-badge--info m-badge--wide'>Added Items Total "+a_count+"</span></span>";						
					}
					
					uploadContent += '<span class="m-menu__link-badge pull-right"><span class="m-badge m-badge--success m-badge--wide">uploaded</span></span></p>';
					
					
					$('<div/>').addClass("uploaded-file").html(uploadContent).appendTo('#files');
				});
				toastr.success(result.message);
			}else{
				toastr.error(result.message);
			}
			
        },
        progressall: function (e, data) {
			$("#progress").show();
            var progress = parseInt(data.loaded / data.total * 100, 10);
			var progressTotal = 0;
			
			var steps = setInterval(function(){
				progressTotal+=10;
				$('#progress .progress-bar').css('width', progressTotal + '%');
				if(progressTotal == 100){
					clearInterval(steps);
					progressTotal = 0;
					setTimeout(function(){
						$('#progress .progress-bar').css('width', progressTotal + '%');						
					}, 1500);
				}
			}, 10);
			
			if(progress == 100){
				setTimeout(function(){
					$("#progress").hide();					
				}, 1000);
			}
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
});
</script>