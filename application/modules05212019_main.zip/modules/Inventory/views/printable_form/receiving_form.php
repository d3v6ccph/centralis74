<div id="printable_issuance-form" align="center">
<style>
img#header-logo {
    max-width: 135px;
	position: relative;
    left: 50px;
}
#form-input_content-footer span {
	width: 100%;
    display: inline-block;
    height: 35px;
}
#form-input_content span {
	width: 200px;
	display: inline-block;
	text-align: left;
}
table#form-input_table {
	border-collapse: collapse;
} 
table#form-input_table, table#form-input_table th, table#form-input_table td {
	border: 1px solid #000000;
}
div.form-title-container h3, div.form-title-container p {
	margin: 0;
}
div#printable_issuance-form p, div#printable_issuance-form label {
	font-size: 14px;
}
div#printable_issuance-form table th,
div#printable_issuance-form table td{
	font-size: 14px;
}
div.form-header {
    margin-top: 20px;
}
p.notes-section {
    line-height: 18px;
}
table, th, td {
    text-transform: uppercase;
}
@media print {
	img#header-logo {
		max-width: 135px;
		position: relative;
		left: 50px;
	}
	#form-input_content-footer span {
		width: 100%;
		display: inline-block;
		height: 35px;
	}
	#form-input_content span {
		width: 200px;
		display: inline-block;
		text-align: left;
	}
	table#form-input_table {
		border-collapse: collapse;
	} 
	table#form-input_table, table#form-input_table th, table#form-input_table td {
		border: 1px solid #000000;
	}
	div.form-title-container h3, div.form-title-container p {
		margin: 0;
	}
	div#printable_issuance-form p, div#printable_issuance-form label {
		font-size: 14px;
	}
	div#printable_issuance-form table th,
	div#printable_issuance-form table td{
		font-size: 14px;
	}
	div#printable_issuance-form {
		margin: 15px 0px;
	}
	div.form-header {
		margin-top: 20px;
	}
	p.notes-section {
		line-height: 18px;
	}
	table, th, td {
		text-transform: uppercase;
	}
}
</style>
<div class="form-header">
	<table width="780">
		<col width="195">
		<col width="585">
		<tbody>
			<tr>
				<td style="vertical-align: top;">
					<div class="form-title-container">
						<table width="100%">
							<thead>
								<tr>
									<td align="center">
										<h3>RECEIVING REPORT<?php echo (isset($core_data->site_name) && $core_data->site_name)? " - ".strtoupper($core_data->site_name):""; ?></h3>
										<p><small><span>HW-FM-IMA-003</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>Rev 0</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>10/01/13</span></small></p>
									</td>
								</tr>
							</thead>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div class="form-body">
<table width="780">
	<tbody>
		<tr>
			<td align="center">
				<table id="form-input_content" width="100%" cellpadding="0" cellspacing="0">
					<tbody>
						<tr>
							<td align="left">
								<div class="content-input-1" style="margin-bottom: 5px;">
									<label style="width: 125px; display: inline-block; margin-right: 10px;">Supplier's Name:</label>
									<span style="line-height: 18px; margin-right: 150px;"><?php echo (isset($receiving_data->supplier) && $receiving_data->supplier)? strtoupper($receiving_data->supplier): "&nbsp;"; ?></span>
								</div>
							</td>
							<td align="left">
								<div class="content-input-1" style="margin-bottom: 5px;">
									<label style="font-weight: 700; width: 60px; display: inline-block; margin-right: 10px;">RR#:</label>
									<span style="line-height: 18px; "><?php echo (isset($receiving_data->reference_no) && $receiving_data->reference_no)? $receiving_data->reference_no: "&nbsp;"; ?></span>
								</div>
							</td>
						</tr>
						<tr>
							<td align="left">
								<div class="content-input-1" style="margin-bottom: 5px;">
									<label style="width: 125px; display: inline-block; margin-right: 10px;">Invoice/ DR No:</label>
									<span style="line-height: 18px; margin-right: 150px;"><?php echo (isset($receiving_data->invoice_dr_no) && $receiving_data->invoice_dr_no)? strtoupper($receiving_data->invoice_dr_no): "&nbsp;"; ?></span>
								</div>
							</td>
							<td align="left">
								<div class="content-input-1" style="margin-bottom: 5px;">
									<label style="width: 60px; display: inline-block; margin-right: 10px;">Date:</label>
									<span style="line-height: 18px;"><?php echo (isset($receiving_data->received_date) && $receiving_data->received_date)? date("m/d/Y", strtotime($receiving_data->received_date)): "&nbsp;"; ?></span>
								</div>
							</td>
						</tr>
						<tr>
							<td align="left">
								<div class="content-input-1">
									<label style="width: 125px; display: inline-block; margin-right: 10px;">Project Name:</label>
									<span style="line-height: 18px; margin-right: 150px;"><?php echo (isset($receiving_data->project_name) && $receiving_data->project_name)? strtoupper($receiving_data->project_name): "&nbsp;"; ?></span>
								</div>
							</td>
							<td align="left">
								<div class="content-input-1">
									<label style="width: 60px; display: inline-block; margin-right: 10px;">P.O. No:</label>
									<span style="line-height: 18px;"><?php echo (isset($receiving_data->po_no) && $receiving_data->po_no)? strtoupper($receiving_data->po_no): "&nbsp;"; ?></span>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		<tr>
			<td style="line-height: 5px; height: 5px;">&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table id="form-input_table" width="100%" cellpadding="3" cellspacing="0">
					<!-- <col width="15%">
					<col width="8%">
					<col width="8%">
					<col width="*"> -->
					<thead>
						<th align="left">Stock Code</th>
						<th align="center">Unit</th>
						<th align="center">Item Description</th>
						<th align="center">Qty</th>
						<th align="center">Unit Price</th>
						<th align="center">Amount</th>
					</thead>
					<tbody>
						<?php if($receiving_item): $total = 0; ?>
						<?php foreach($receiving_item as $data): $amount = 0; $amount = $data->qty * floatval(str_replace(",", "", $data->unit_price)); $total = $total + $amount;  ?>
						<tr>
							<td><?php echo (isset($data->sku) && $data->sku)? strtoupper($data->sku): ""; ?></td>
							<td align="center"><?php echo (isset($data->uom_code) && $data->uom_code)? strtoupper($data->uom_code): ""; ?></td>
							<td><?php echo (isset($data->name) && $data->name)? strtoupper($data->name): ""; ?></td>
							<td align="center"><?php echo (isset($data->qty) && $data->qty)? $data->qty: ""; ?></td>
							<td align="right"><?php echo (isset($data->unit_price) && $data->unit_price)? $data->unit_price: ""; ?></td>
							<td align="right"><?php echo number_format($amount,2,".",","); ?></td>
						</tr>
						<?php endforeach; ?>
						<?php else: ?>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<?php endif; ?>
					</tbody>
					<tfoot>
						<tr>
							<th colspan="5" align="right">Total</th>
							<td align="right"><?php echo number_format($total,2,".",","); ?></td>
						</tr>
					</tfoot>
				</table>
			</td>
		</tr>
		<tr>
			<td style="line-height: 5px; height: 5px;">&nbsp;</td>
		</tr>
		<tr>
			<td>
				<table id="form-input_content-notes" width="100%" cellpadding="0" cellspacing="0">
					<col width="8%">
					<col width="*">
					<tbody>
						<tr>
							<td style="vertical-align: top; font-weight: 700; margin-right: 10px; display: inline-block;">Remarks:</td>
							<td><p class="notes-section"><?php echo (isset($receiving_data->remarks) && $receiving_data->remarks)? strtoupper($receiving_data->remarks): "&nbsp;"; ?></p></td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
	</tbody>
</table>
</div>
<div class="form-footer">
<table width="780">
	<tbody>
		<tr>
			<td style="line-height: 25px; height: 25px;">&nbsp;</td>
		</tr>
		<tr>
			<td align="center">
				<table id="form-input_content" width="100%" cellpadding="0" cellspacing="0">
					<tbody>
						<tr>
							<td align="left">
								<div class="content-input-2">
									<label>Received By:</label>
									<span style="margin-left: 10px;"><?php echo (isset($receiving_data->received_by) && $receiving_data->received_by)? strtoupper($receiving_data->received_by): "&nbsp;"; ?></span>
								</div>
							</td>
							<td align="right">
								<div class="content-input-2">
									<label>Noted By:</label>
									<span style="margin-left: 10px; border-bottom: 0.5px solid #000000;">&nbsp;</span>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
</table>
</div>
<script>
setTimeout(function(){
	window.print();
	window.close();
}, 200);
</script>
</div>