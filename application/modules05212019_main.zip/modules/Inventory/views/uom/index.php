<?php $actions = $this->core_layout->getCurrentActions(); ?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Inventory - Units
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-inventory_uom" width="100%">
								<thead>
									<tr>
										<th>Code</th>
										<th>Description</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
			<!--end::Portlet-->
		</div>
	</div>
</div>
<!--begin::Modal-->
<div class="modal fade" id="modal-inventory_uom-new" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('inventory/add_uom'); ?>" method="POST" id="form-uom-new">
			<div class="modal-header"><h5 class="modal-title">New Units</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">Code</label>
					<input type="text" name="uom_code" class="form-control inptCode" data-validation="required">
				</div>
				<div class="form-group">
					<label class="form-control-label">Description</label>
					<textarea class="form-control txtuomDesc" name="uom_desc" data-validation="required"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit btnSave">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-inventory_uom-edit" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('inventory/update_uom'); ?>" method="POST" id="form-uom-edit">
			<input type="hidden" class="inptId" name="id" v-model="item_update.id" />
			<div class="modal-header">
				<h5 class="modal-title" >Update Units</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">Code</label>
					<input type="text" name="uom_code" class="form-control inptCode" v-model="item_update.uom_code" data-validation="required">
				</div>
				<div class="form-group">
					<label class="form-control-label">Description</label>
					<textarea class="form-control txtuomDesc" name="uom_desc" v-model="item_update.uom_desc" data-validation="required"></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit btnUpdate">Save</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-inventory_uom-delete" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<input type="hidden" id="removeUom" value="0" />
			<div class="modal-header">
				<h5 class="modal-title">Delete Units</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body"><i class="la la-warning"></i>  Are you sure you want to delete this uom? </div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary btn-submit-delete btnDelete">Delete</button>
				<button class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
var _currentActions = <?php echo json_encode($actions); ?>;
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";
var _tableUom = $("#table-inventory_uom");
var _modalUom = $("#modal-inventory_uom-new");
var _modalUomEdit = $("#modal-inventory_uom-edit");
var _modalUomDelete = $("#modal-inventory_uom-delete");
	
var _dtTable = $("#table-inventory_uom").DataTable({
	dom: '<"toolbar">frtlip',
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("inventory/get_uom_list"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "uom_code", width: "20%" },
		{ data: "uom_desc", width: "70%" },
		{ data: null, width: "10%"},
	], columnDefs: [{
		data: null,
		defaultContent: "",
		targets: -1,
		orderable: false,
		render: function ( data, type, row, meta ) { return uomDatatableActions(row.id); },
	}, { 
		targets: "_all", 
		defaultContent: "", 
	}],
	initComplete: function(settings, json){
		if(typeof roleActionUpdate == "function"){ roleActionUpdate(); }
	}
});

$("div.toolbar").html('<button type="button" id="inventory_uom-new" class="m-portlet__nav-link btn m-btn--square btn-success btnNew"  data-toggle="modal" data-target="#modal-inventory_uom-new"><i class="fa fa-plus"></i> New </button>');

function uomDatatableActions($id){
	if($id){
		var _actionButton ="";
		if(typeof _currentActions !== "undefined" && jQuery.inArray("edit", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnEditUom' data-id='"+$id+"'><i class='la la-edit'></i></button>";				
		}
		if(typeof _currentActions !== "undefined" && jQuery.inArray("delete", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill btnRemoveUom' data-id='"+$id+"'><i class='la la-trash'></i></button>";				
		}
		return _actionButton;
	}else{ return false; }
}

$(document).on("click", "#table-inventory_uom .btnEditUom", function(){
	var _dataId = $(this).data("id");
	
	$.ajax({
		url: "<?php echo site_url("inventory/get_inventory_uom"); ?>",
		type: "post",
		dataType: "json",
		data: { id: _dataId },
		success: function(json){
			if(json.response){
				vm.item_update = json.value;
				_modalUomEdit.modal("show");
			}else{
				toastr.error(json.toastr_msg, "Error Units Data", 5000);
			}
		}
		
	});	
});

jQuery(document).on("click", "#table-inventory_uom .btnRemoveUom", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	var _inptAcl = _modalUomDelete.find("#removeUom");
	if(typeof _inptAcl !== "undefined"){
		_inptAcl.val(dataId);
		$(_modalUomDelete).modal("show");
	}
});
	
jQuery(document).on("click", ".btn-submit-delete", function(){
	var _btnSubmit = jQuery(this);
	var _dataId = jQuery(this).parent(".modal-footer").parent(".modal-content").children("input#removeUom").val();
	if(typeof _dataId !== "undefined"){
		jQuery.ajax({
			url: "<?php echo base_url("inventory/remove_uom"); ?>",
			type: "post",
			data: { id: _dataId },
			beforeSend: function(){
				if(typeof _btnSubmit !== "undefined"){
					if(!_btnSubmit.hasClass("m-btn--custom m-loader m-loader--light m-loader--right")){
						_btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right");
					}
				}
			},
			success: function(json){
				if(json.response){
					toastr.success(json.toastr_msg, "Remove Units", 5000);
					$(_modalUomDelete).modal("hide");
					setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
				}else{ toastr.error(json.toastr_msg, "Error removing units", 5000); }
				if(typeof _btnSubmit !== "undefined"){
					if(_btnSubmit.hasClass("m-btn--custom m-loader m-loader--light m-loader--right")){
						_btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right");							
					}
				}
			}
		});			
	}
});

$.validate({
	form : '#form-uom-new',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			data: $("#form-uom-new").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(data){
				if(data.response){
					form[0].reset();
					toastr.success(data.toastr_msg, "Added Units", 5000);
					$("#modal-inventory_uom-new").modal("hide");
					setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
				}else{
					toastr.error(data.toastr_msg, "Error Units", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
			}
		});
		return false;
	},
});

var _items = { id: 0, name: "", uom_code: "", uom_desc: "" };
var vm = new Vue({
	el: "#form-uom-edit",
	data: {	item_update: _items },
	mounted: function(){
		$.validate({
			form : '#form-uom-edit',
			lang: 'en',
			onSuccess : function(form) {
				var _url = form[0].action;
				var _data = jQuery(form[0]).serialize();
				var _btnSubmit = $(form[0]).find(".btn-submit");
				
				$.ajax({
					url: _url,
					type: "POST",
					data: _data,
					beforeSend: function(){
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					},
					success: function(data){
						if(data.response){
							toastr.success(data.toastr_msg, "Update units", 5000);
							_modalUomEdit.modal("hide");
							setTimeout(function(){ _dtTable.ajax.reload(); }, 500);
						}else{
							toastr.error(data.toastr_msg, "Error units", 5000);
						}
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					}
				});
				
				return false;
			}
		});
	}
});
</script>