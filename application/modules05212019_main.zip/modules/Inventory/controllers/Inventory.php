<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Inventory extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("inventory/uom_model");
		$this->load->model("inventory/items_model");
	}
	public function index(){
		$this->load->view('core/templates/header');
		$this->load->view('index');
		$this->load->view('core/templates/footer');
	}
	
	public function items(){
		$this->core_layout->setPageTitle("Inventory - Items");
		$this->core_layout->setBodyClass("inventory inventory_items");
		$this->core_layout->setPrivilegeName("inventory_items");
		
		$this->core_layout->addJs("plugins/fileupload/js/vendor/jquery.ui.widget.js");
		$this->core_layout->addJs("plugins/fileupload/js/jquery.iframe-transport.js");
		$this->core_layout->addJs("plugins/fileupload/js/jquery.fileupload.js");
		$this->core_layout->addCss("plugins/fileupload/css/jquery.fileupload.css");
		$this->load->view('core/templates/header');
		$this->load->view('items/index');
		$this->load->view('core/templates/footer');
	}
	
	function add_item(){
		$resultset = array();
		$resultset = $this->items_model->addInventoryItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	public function get_item_list(){
		$data = $this->items_model->getItemsList();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	public function uom(){
		$this->core_layout->setPageTitle("Inventory - Uom");
		$this->core_layout->setBodyClass("inventory inventory_uom");
		$this->core_layout->setPrivilegeName("inventory_uom");
		
		$this->load->view('core/templates/header');
		$this->load->view('uom/index');
		$this->load->view('core/templates/footer');
	}
	
	function add_uom(){
		$resultset = array();
		$resultset = $this->uom_model->addInventoryUom();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	public function get_uom_list(){
		$data = $this->uom_model->getUomList();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	public function get_inventory_uom(){
		$data = $this->uom_model->getInventoryUomItem();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	public function get_inventory_item(){
		$data = $this->items_model->getInventoryItemData();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	/** update section **/
	function update_uom(){
		$resultset = array();
		$resultset = $this->uom_model->updateInventoryUom();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	function update_items(){
		$resultset = array();
		$resultset = $this->items_model->updateInventoryItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	/** update section **/
	
	function remove_uom(){
		$resultset = array();
		$resultset = $this->uom_model->removeInventoryUom();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	function remove_item(){
		$resultset = array();
		$resultset = $this->items_model->removeInventoryItem();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	public function checkInventoryCode(){
		$data = $this->items_model->checkInventoryCode();
		$this->output
		->set_content_type("json")
		->set_output(json_encode($data));
	}

	function get_issuance_items(){
		$resultset = array();
		$resultset = $this->items_model->getIssuanceItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}

	function select2_get_current_items(){
		$resultset = array();
		$resultset = $this->items_model->select2GetCurrentItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	function get_searched_item(){
		$resultset = array();
		$resultset = $this->items_model->getSearchedItem();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	function get_searched_item_bq(){
		$resultset = array();
		$resultset = $this->items_model->getSearchedItemBq();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	function set_reorder_items(){
		$resultset = array();
		$resultset = $this->items_model->setReorderedItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	function set_beginning_items(){
		$resultset = array();
		$resultset = $this->items_model->setBeginningItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
	
	function readExcel()
	{
        $this->load->library('csvreader');
        $result = $this->csvreader->parse_file(base_url('uploads/stocks/12345.csv'));

        $data['csvData'] =  $result;
        echo "<pre>";
        var_dump($data);
        //$this->load->view('view_csv', $data);  
	}

	function moveUploadedFile(){
		echo "<pre>";
		$config['upload_path'] = './uploads/stocks';
		$config['allowed_types'] = 'csv';
		$config['max_size']	= '100';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());
       		var_dump($error);
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			var_dump($data);
		}
	}
}