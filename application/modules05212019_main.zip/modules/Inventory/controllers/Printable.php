<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Printable extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("inventory/uom_model");
		$this->load->model("inventory/items_model");
		$this->load->model("inventory/printable_model");
		$this->load->model("core/settings_model", "settings");
	}
	function print_issuance($id=null){
		$issuanceData = $this->printable_model->getIssuanceDataById($id);
		$issuanceItem = $this->printable_model->getIssuanceItemById($id);
		$settingsData = $this->settings->getSettingsData();
		$arrData = array();
		$arrData["issuance_data"] = $issuanceData;
		$arrData["issuance_item"] = $issuanceItem;
		$arrData["core_data"] = $settingsData;
		
		$this->load->view("inventory/printable_form/issuance_form", $arrData);
	}
	function print_receiving_report($id=null){
		$receivingData = $this->printable_model->getReceivingDataById($id);
		$receivingItem = $this->printable_model->getReceivingItemById($id);
		$settingsData = $this->settings->getSettingsData();
		$arrData = array();
		$arrData["receiving_data"] = $receivingData;
		$arrData["receiving_item"] = $receivingItem;
		$arrData["core_data"] = $settingsData;
		
		$this->load->view("inventory/printable_form/receiving_form", $arrData);
	}
}