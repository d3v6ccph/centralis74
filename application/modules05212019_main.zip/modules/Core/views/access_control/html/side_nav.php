<?php
$currentPage = $this->core_layout->getBodyClass();
$hasBodyClass = $this->core_layout->hasBodyClass();
?>
<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">
<?php if(isset($aclMenu, $roleResource) && ($aclMenu && $roleResource)): ?>
<?php foreach($aclMenu as $menu): ?>
<?php
	$menuName = (isset($menu["name"]) && $menu["name"])? $menu["name"]: "";
	$activeMenu = "";
	
	$explodeCurrentPage = explode(" ", $currentPage);
	if(count($explodeCurrentPage) > 0){
		$activeMenu = ($hasBodyClass && in_array($menuName, $explodeCurrentPage))? " m-menu__item--active": "";
	}
	
	$subMenu = (isset($menu["children"]) && $menu["children"])? " m-menu__item--submenu":"";
	$toggleMenu = (isset($menu["children"]) && $menu["children"])? " data-menu-submenu-toggle='hover'":"";
	$menuToogle = (isset($menu["children"]) && $menu["children"])? " m-menu__toggle":"";
	$menuUrl = (isset($menu["url"]) && $menu["url"])? base_url($menu["url"]): "javascript:void(0);";
	$menuIcon = (isset($menu["icon"]) && $menu["icon"])? $menu["icon"]: "";
	$menuLabel = (isset($menu["label"]) && $menu["label"])? $menu["label"]: "";
?>
<?php if(isset($menu["id"]) && ($menu["id"] && in_array(intval($menu["id"]), $roleResource)) && $menuIcon !== "m-menu__item--hidden"): ?>
	<li class="m-menu__item<?php echo "{$subMenu}{$activeMenu}"; ?>" aria-haspopup="true"<?php echo $toggleMenu; ?>>
		<a  href="<?php echo $menuUrl; ?>" class="m-menu__link<?php echo $menuToogle; ?>">
			<span class="m-menu__item-here"></span>
			<i class="m-menu__link-icon <?php echo $menuIcon; ?>"></i>
			<span class="m-menu__link-text"><?php echo $menuLabel; ?></span>
		<?php if(isset($menu["children"]) && $menu["children"]): ?>
			<i class="m-menu__ver-arrow la la-angle-right"></i>
		<?php endif; ?>
		</a>
	<?php if(isset($menu["children"]) && $menu["children"]): ?>
		<div class="m-menu__submenu">
			<span class="m-menu__arrow"></span>
			<ul class="m-menu__subnav">
		<?php foreach($menu["children"] as $child):
			$menuIconChild = (isset($child["icon"]) && $child["icon"])? $child["icon"]: "";
			if(in_array($child["id"], $roleResource) && $menuIconChild !== "m-menu__item--hidden"):
			$childUrl = (isset($child["url"]) && $child["url"])? base_url($child["url"]): "javascript:void(0);";
			$childLabel = (isset($child["label"]) && $child["label"])? $child["label"]: ""; ?>
				<li class="m-menu__item  m-menu__item--parent" aria-haspopup="true" >
					<a  href="<?php echo $childUrl; ?>" class="m-menu__link ">
						<span class="m-menu__item-here"></span>
						<span class="m-menu__link-text"><?php echo $childLabel; ?></span>
					</a>
				</li>
		<?php endif; endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>
	</li>
<?php endif; ?>
<?php endforeach; ?>
<?php else: ?>
<li class="m-menu__item m-menu__item--active" aria-haspopup="true" >
	<a  href="<?php echo base_url(); ?>" class="m-menu__link ">
		<span class="m-menu__item-here"></span>
		<i class="m-menu__link-icon flaticon-line-graph"></i>
		<span class="m-menu__link-text">Dashboard</span>
	</a>
</li>
<?php endif; ?>
</ul>