<?php $actions = $this->core_layout->getCurrentActions(); ?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">Manage Users</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item"></li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-users" width="100%">
								<thead>
									<tr>
										<th>Biometric No</th>
										<th>Lastname</th>
										<th>Firstname</th>
										<th>Middlename</th>
										<th>Email</th>
										<th>Assigned Role</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
			<!--end::Portlet-->
		</div>
	</div>
</div>

<!--begin::Modal-->
<div class="modal fade" id="modal-user_role-assign" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content"></div>
	</div>
</div>
<script>
var _modalAssignRole = $("#modal-user_role-assign");

var _currentActions = <?php echo json_encode($actions); ?>;
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";
var _dtUsers = $("#table-users").DataTable({
	dom: '<"toolbar">frtlip',
	paging: false,
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("core/users/get_user_list"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash },
		dataFilter: function(response){
			var _result = JSON.parse(response);
			var _data = _result.data;
			if(typeof _data !== "undefined"){
				_data.forEach(function(row, index){
					if(typeof row.biometricno !== "undefined"){ var _bio = (row.biometricno)? row.biometricno: "---"; }
					if(typeof row.description !== "undefined"){ var _desc = (row.description)? row.description.ucWords(): "Unassigned"; }
					if(typeof row.lastname !== "undefined"){ var _lname = row.lastname.ucWords(); }
					if(typeof row.firstname !== "undefined"){ var _fname = row.firstname.ucWords(); }
					if(typeof row.middlename !== "undefined"){ var _mname = row.middlename.ucWords(); }
					if(typeof row.email !== "undefined"){ var _email = (row.email)? row.email.toLowerCase(): "none"; }
					
					if(typeof _result.data[index].biometricno !== "undefined" && _bio !== "undefined"){ _result.data[index].biometricno = _bio; }
					if(typeof _result.data[index].description !== "undefined" && _desc !== "undefined"){ _result.data[index].description = _desc; }
					if(typeof _result.data[index].lastname !== "undefined" && _lname !== "undefined"){ _result.data[index].lastname = _lname; }
					if(typeof _result.data[index].firstname !== "undefined" && _fname !== "undefined"){ _result.data[index].firstname = _fname; }
					if(typeof _result.data[index].middlename !== "undefined" && _mname !== "undefined"){ _result.data[index].middlename = _mname; }
					if(typeof _result.data[index].email !== "undefined" && _email !== "undefined"){ _result.data[index].email = _email; }
				});
			}
			
			var _response = JSON.stringify(_result);
			return _response;
		},
		error: function (xhr, error, thrown) {
			console.log( error );
		},
	}, columns: [
		{ data: "biometricno", width: "10%" },
		{ data: "lastname", width: "15%" },
		{ data: "firstname", width: "15%" },
		{ data: "middlename", width: "15%" },
		{ data: "email", width: "15%" },
		{ data: "description", width: "20%" },
		{ data: "employee_status", width: "5%"},
		{ data: null, width: "5%"},
	], columnDefs: [{
		data: null,
		defaultContent: "",
		targets: -1,
		orderable: false,
		render: function ( data, type, row, meta ) { return userDatatableActions(row.id); },
	},{
		data: "employee_status",
		defaultContent: "",
		targets: 6,
		orderable: false,
		className: "dt-column-center",
		render: function ( data, type, row, meta ) { return userDatatableStatus(row.employee_status); },
	}, { 
		targets: "_all", 
		defaultContent: "", 
	}], 
	scrollY: '55vh',
	scrollCollapse: true,
	initComplete: function(settings, json){
		if(typeof aclActionUpdate == "function"){ aclActionUpdate(); }
	}
});

function userDatatableActions($id){
	if($id){
		var _actionButton ="";
		if(typeof _currentActions !== "undefined" && jQuery.inArray("edit", _currentActions) !== -1){
			_actionButton += "<button type='button' class='btn btn-default m-btn m-btn--hover-accent btn-sm m-btn--icon m-btn--icon-only m-btn--pill btnAssignUser' data-id='"+$id+"'><i class='la la-edit'></i></button>";			
		}
		return _actionButton;
	}else{ return false; }
}
function userDatatableStatus($status){
	var _html = "";
	if($status == "Active"){
		_html = "<span class='btn btn-success m-btn m-btn--icon m-btn--icon-only btn-sm' data-toggle='m-popover' data-placement='top' data-content='"+$status+"'><i class='la la-user'></i></span>";
	}else{
		$status = ($status==null)? "Development": $status; 
		_html = "<span class='btn btn-danger m-btn m-btn--icon m-btn--icon-only btn-sm' data-toggle='m-popover' data-placement='top' data-content='"+$status+"'><i class='la la-user'></i></span>";
	}
	return _html;
}

jQuery(document).on("click", "#table-users .btnAssignUser", function(){
	var dataId = $(this).data("id");
	console.log(dataId);
	$.ajax({
		url: "<?php echo site_url("core/users/get_user_data"); ?>",
		type: "POST",
		dataType: "JSON",
		data: { id: dataId },
		success: function(json){
			if(json.response){
				var _modalContent = _modalAssignRole.find(".modal-content");
				if(typeof _modalContent !== "undefined"){
					_modalContent.empty().append(json.html);
					$(_modalAssignRole).modal("show");
				}
			}
		}
	});
	
});

jQuery(document).on("click", "#modal-user_role-assign #form-users-assign .btn-submit", function(){
	var _self = $(this);
	var _form = _self.parent(".modal-footer").parent("#form-users-assign");
	if(typeof _form !== "undefined"){
		$.ajax({
			url: _form.attr("action"),
			type: "POST",
			dataType: "JSON",
			data: _form.serialize(),
			success: function(json){
				if(json.response){
					toastr.success(json.message, "Assign User Role", 5000);
					$(_modalAssignRole).modal("hide");
					setTimeout(function(){ window.location.reload(); }, 1000);
				}else{
					toastr.error(json.message, "Assign User Role",  5000);
				}
			}
		});		
	}
});
</script>
<!--end::Modal-->