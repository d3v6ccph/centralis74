<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Upload_model extends CI_Model{
	function __construct(){
		parent::__construct();
	}
	
	function uploadFile($config=array()){
		$resultset = array();
		$files = (isset($_FILES["files"]) && $_FILES["files"])? $_FILES["files"]: false;
		if($config){
			$this->upload->initialize($config);
			
			if($files){
				foreach($files["name"] as $key => $image){
					$_FILES["files"]["name"] = $files["name"][$key];
					$_FILES["files"]["type"] = $files["type"][$key];
					$_FILES["files"]["tmp_name"] = $files["tmp_name"][$key];
					$_FILES["files"]["error"] = $files["error"][$key];
					$_FILES["files"]["size"] = $files["size"][$key];
				}
				
				if (!$this->upload->do_upload('files')){
						$error = array('error' => $this->upload->display_errors());
						$resultset["response"] = false;
						$resultset["data"] = $error;
						$resultset["message"] = $this->upload->display_errors();
				}else{
					$data = $this->upload->data();
					if($data){
						$resultset["response"] = true;
						$resultset["files"][] = $data;
						$resultset["message"] = "upload file successful.";
					}else{
						$resultset["response"] = false;
						$resultset["message"] = "no data to upload!";
					}
				}
			}else{
				$resultset["response"] = false;				
				$resultset["message"] = "no file to upload!";
			}
		}else{
			$resultset["response"] = false;
			$$resultset["message"] = "upload configuration was not set!";
		}
		
		return $resultset;
	}
}