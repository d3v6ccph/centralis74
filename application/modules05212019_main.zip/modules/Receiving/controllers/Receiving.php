<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Receiving extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("Receiving_model","receiving");
		$this->load->model("core/settings_model","settings");

		date_default_timezone_set('Asia/Manila');
	}
	
	public function index(){
		$this->core_layout->setPageTitle("Transaction - Receiving");
		$this->core_layout->setBodyClass("transaction receiving");
		$this->core_layout->setPrivilegeName("receiving");

		$this->load->view('core/templates/header');
		$this->load->view('index');
		$this->load->view('core/templates/footer');
	}

	function add_new_page(){
		$this->core_layout->setPageTitle("Transaction - Receiving New");
		$this->core_layout->setBodyClass("transaction receiving");
		$this->core_layout->setPrivilegeName("receiving");

		$this->load->view('core/templates/header');
		$this->load->view('add_new_page');
		$this->load->view('core/templates/footer');
	}

	function get_receiving_list(){
		$data = $this->receiving->getReceivingList();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_item_data(){
		$post = $this->input->post();
		$data = $this->receiving->getItemData($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_receiving_content_temp(){
		$data = $this->receiving->getReceivingContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_receiving_content(){
		$post = $this->input->post();
		$data = $this->receiving->getReceivingContent($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function add_receiving_content_temp(){
		$data = $this->receiving->addReceivingContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function saveReceiving(){
		$data = $this->receiving->saveReceiving();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function getReceiving(){
		$post = $this->input->post();
		$data = $this->receiving->getReceiving($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function remove_item_content_temp(){
		$data = $this->receiving->removeItemContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_item(){
		$data = $this->receiving->getItem();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function update_receiving_content_temp(){
		$data = $this->receiving->updateReceivingContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function cancel_receiving(){
		$data = $this->receiving->cancelReceiving();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_receiving_archives(){
		$data = $this->receiving->getReceivingArchives();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

}
