<?php $actions = $this->core_layout->getCurrentActions(); ?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Receiving
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item m-dropdown m-dropdown--inline m-dropdown--arrow m-dropdown--align-right m-dropdown--align-push" data-dropdown-toggle="hover" aria-expanded="true">
								<a href="#" class="m-portlet__nav-link m-portlet__nav-link--icon m-portlet__nav-link--icon-xl">
									<i class="la la-ellipsis-h m--font-brand"></i>
								</a>
								<div class="m-dropdown__wrapper">
									<span class="m-dropdown__arrow m-dropdown__arrow--right m-dropdown__arrow--adjust" style="left: auto; right: 22.5px;"></span>
									<div class="m-dropdown__inner">
										<div class="m-dropdown__body">
											<div class="m-dropdown__content">
												<ul class="m-nav">
													<li class="m-nav__section m-nav__section--first">
														<span class="m-nav__section-text">
															Quick Action
														</span>
													</li>
													<li class="m-nav__item">
														<a href="javascript:void()" class="m-nav__link" data-toggle="modal" data-target="#modal_archives">
															<i class="m-nav__link-icon flaticon-open-box"></i>
															<span class="m-nav__link-text">
																Archives
															</span>
														</a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-receiving" width="100%">
								<thead>
									<tr>
										<th>Reference #</th>
										<th>Invoice/DR #</th>
										<th>Supplier</th>
										<th>Date</th>
										<th>Time</th>
										<th>Received By</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
			<!--end::Portlet-->
		</div>
	</div>
</div>

<!-- Modal View Transaction Begin -->
<div class="modal fade" id="modal-view-receiving" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="display: none; z-index: 9999;" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Receiving view
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">
						×
					</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Supplier Name:
								</label>
								<input disabled="disabled"  type="text" name="supplier" class="form-control m-input" data-validation="required">
							</div>
							<div class="form-group m-form__group">
								<label>
									Invoice / DR No.:
								</label>
								<input disabled="disabled"  type="text" name="invoice_dr_no" class="form-control m-input" data-validation="required">
							</div>
							<div class="form-group m-form__group">
								<label>
									Project Name:
								</label>
								<input disabled="disabled"  type="text" name="project_name" class="form-control m-input" data-validation="required">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group m-form__group">
								<label>
									Reference No.:
								</label>
								<input disabled="disabled"  type="text" name="reference_no" class="form-control m-input" data-validation="required">
							</div>
							<div class="form-group m-form__group">
								<label>
									Date Received:
								</label>
								<input disabled="disabled"  type="text" name="received_date" class="form-control m-input" data-validation="required">
							</div><div class="form-group m-form__group">
								<label>
									PO No.:
								</label>
								<input disabled="disabled"  type="text" name="po_no" class="form-control m-input" data-validation="required">
							</div>
							<div class="form-group m-form__group">
								<label>
									Remarks
								</label>
								<textarea disabled="disabled"  class="form-control m-input" name="remarks"  rows="3"></textarea>
							</div>
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll col-md-12">
							<div class="row">
								<div class="col-md-12">
									<table class="table table-striped table-bordered m-datatable__table" id="table-receiving-contents" width="100%">
										<thead>
											<tr>
												<th>Stock Code</th>
												<th>Item Description</th>
												<th>Unit</th>
												<th>Qty</th>
												<th>Unit Price</th>
												<th>Amount</th>
											</tr>
										</thead>
										<tbody>	

										</tbody>
										<tfoot align="right">
											<tr>
												<th colspan="5" align="right">Total</th>
												<th></th>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-danger" data-dismiss="modal">Close</button>
				<button class="btn btn-primary btnPrint">Print</button>
			</div>
		</div>
	</div>
</div>
<!-- Modal View Transaction End -->

<!-- Modal Cancel Remarks Begin -->
<div class="modal fade" id="modal_cancel_remarks" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<form id="formCancel" action="<?php echo site_url('receiving/cancel_receiving'); ?>" method="POST">
			<input type="hidden" name="id">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">
						Cancel Receiving Transaction
					</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">
							×
						</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group m-form__group">
									<label>
										Reason for cancellation:
									</label>
									<textarea class="form-control m-input" name="cancel_remarks" data-validation="required"></textarea>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-danger" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary btn-submit btnDelete">Proceed</button>
				</div>
			</div>
		</form>
	</div>
</div>
<!-- Modal View Transaction End -->

<!-- Modal Archives Begin -->
<div class="modal fade" id="modal_archives" tabindex="1" role="dialog" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document" style="max-width: 80%;">		
		<div class="modal-content" >
			<div class="modal-header">
				<h5 class="modal-title">
					Receiving Archives
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">
						×
					</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
					<div class="row">
						<div class="col-md-12">
							<table class="table table-striped table-bordered" id="table-receiving-archives" width="100%">
								<thead>
									<tr>
										<th>Reference #</th>
										<th>Supplier</th>
										<th>Date</th>
										<th>Time</th>
										<th>Cancelled By</th>
										<th>Remarks</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Modal Archives End -->

<script type="text/javascript">
var _currentActions = <?php echo json_encode($actions); ?>;
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";
var _global_id = 0;
var _modalPrint = $("#modal-view-receiving");

var _dtUserRole = $("#table-receiving").DataTable({
	dom: '<"toolbar">frtlip',
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("receiving/get_receiving_list"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "reference_no"},
		{ data: "invoice_dr_no"},
		{ data: "supplier"},
		{ data: "received_date"},
		{ data: "received_time"},
		{ data: "created_by"},
		{ data: null, width: "8%", className: "text-center" },
	], columnDefs: [{
		data: null,
		defaultContent: "",
		targets: -1,
		orderable: false,
		render: function ( data, type, row, meta ) { return itemDatatableActions(row.id); },
	}, { 
		targets: "_all", 
		defaultContent: "", 
	}],
	order: [[ 0, "desc" ]],
	initComplete: function(settings, json){
		if(typeof roleActionUpdate == "function"){ roleActionUpdate(); }
	}
});

$("div.toolbar").html('<button type="button" id="receiving-new" class="m-portlet__nav-link btn m-btn--square btn-success btnNew"  data-toggle="modal" data-target="#modal-receiving-new"><i class="fa fa-plus"></i> New </button>');

function itemDatatableActions($id){
	if($id){
		var _actionButton ="";
		if(typeof _currentActions !== "undefined" && jQuery.inArray("edit", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='"+$id+"'><i class='la la-print'></i></button>";				
		}
		if(typeof _currentActions !== "undefined" && jQuery.inArray("cancel", _currentActions) !== -1){
			_actionButton += " <button type='button' class='btn btn-default m-btn m-btn--hover-warning m-btn--icon m-btn--icon-only m-btn--pill btnCancel' data-id='"+$id+"'><i class='la la-ban'></i></button>";				
		}
		return _actionButton;
	}else{ return false; }
}

var dt_recevingArchives = $("#table-receiving-archives").DataTable({
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo site_url("receiving/get_receiving_archives"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	},
	columns: [
		{ data: "reference_no"},
		{ data: "supplier"},
		{ data: "cancelled_date"},
		{ data: "cancelled_time"},
		{ data: "cancelled_by"},
		{ data: "cancel_remarks"},
		{ data: "btn", width: "8%", className: "text-center" },
	]
});

//view receiving transaction on modal
$("#table-receiving-archives").on("click", ".btnViewarchivedContents",function(){
	var id = $(this).attr("data-id");
	$("#modal-view-receiving").modal("show");
	$.ajax({
		url: "<?php echo site_url('receiving/getReceiving');?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success:function(data){
			$("input[name='supplier']").val(data.supplier);
			$("input[name='reference_no']").val(data.reference_no);
			$("input[name='invoice_dr_no']").val(data.invoice_dr_no);
			$("input[name='po_no']").val(data.po_no);
			$("input[name='project_name']").val(data.project_name);
			$("input[name='received_date']").val(data.received_date);
			$("textarea[name='remarks']").val(data.remarks);
			
			$("#modal-view-receiving button.btnPrint").attr("data-id", id);
			_global_id = id;
			dtModalTable.ajax.reload();
		}
	});
});


//navigate to add new page
$("#receiving-new").on("click",function(){
	window.location.href = "<?php echo site_url('receiving/add_new_page')?>";
});

//view receiving transaction on modal
$("#table-receiving").on("click", ".btnEditItem",function(){
	var id = $(this).attr("data-id");
	$("#modal-view-receiving").modal("show");
	$.ajax({
		url: "<?php echo site_url('receiving/getReceiving');?>",
		dataType: "json",
		type: "POST",
		data: {id : id},
		success:function(data){
			$("input[name='supplier']").val(data.supplier);
			$("input[name='reference_no']").val(data.reference_no);
			$("input[name='invoice_dr_no']").val(data.invoice_dr_no);
			$("input[name='po_no']").val(data.po_no);
			$("input[name='project_name']").val(data.project_name);
			$("input[name='received_date']").val(data.received_date);
			$("textarea[name='remarks']").val(data.remarks);
			
			$("#modal-view-receiving button.btnPrint").attr("data-id", id);
			_global_id = id;
			dtModalTable.ajax.reload();
		}
	});
});

var dtModalTable = $("#table-receiving-contents").DataTable({
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("receiving/get_receiving_content"); ?>",
		type: "post",
		dataType: "json",
		data: function (parameter) {
			parameter.id = _global_id;
		},
	},
	footerCallback: function ( row, data, start, end, display ) {
            var api = this.api(), data;
            //console.log(api);
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };

            var total = api
                .column( 5 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );

                $( api.column( 0 ).footer() ).html("TOTAL").css("text-align","right");
                $( api.column( 5 ).footer() ).html(total).css("text-align","right");
    },
    columnDefs: [
    	{ targets: [4,5], className: "text-right"},
    ],
	lengthChange: false,
	bInfo : false,
	paging: false,
	searching: false,

});

//open modal
jQuery(document).on("click", ".btnCancel", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	$("#modal_cancel_remarks input[name=id]").val(dataId);
	$("#modal_cancel_remarks").modal("show");
});

// cancel receiving
$.validate({
	form : '#formCancel',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			dataType: "json",
			data: $("#formCancel").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(json){
				if(json.response){
					toastr.success(json.toastr_msg, "Cancelled Receiving", 5000);
					$("#modal_cancel_remarks").modal("hide");
					setTimeout(function(){
						_dtUserRole.ajax.reload();						
					}, 500);
				}else{
					toastr.error(json.toastr_msg, "Error Cancelled Receiving", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
			}
		});
		return false;
	},
});

jQuery(document).on("click", ".btnPrint", function(){
	var _self = $(this);
	var dataId = _self.data("id");
	
	var toId = (dataId == _global_id)? dataId: _global_id;
	_modalPrint.modal("hide");
	window.open("<?php echo site_url("inventory/printable/print_receiving_report"); ?>"+"/"+toId, "_blank");
});
</script>