<?php
	$actions = $this->core_layout->getCurrentActions();
	$countData = $this->db->count_all_results('receiving');
	$countData = $countData + 1;
	$receivingSuppliers = $this->receiving->getAllSuppliers();
	
	$coreData = $this->settings->getSettingsData();
	$siteCode = (isset($coreData->site_code) && $coreData->site_code)? strtoupper($coreData->site_code):"";
	
	$refgen = ($siteCode)? "RR-{$siteCode}-000{$countData}":"RR-000{$countData}";
?>
<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
		<form id="add_receving_form" method="POST" action="<?php echo site_url('receiving/saveReceiving');?>">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Receiving
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Form -->
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group m-form__group">
									<label>
										Supplier Name:
									</label>
									<div class="m-typeahead">
										<input id="m_typeahead_1" type="text" name="supplier" class="form-control m-input tt-input" data-validation="required" autocomplete="off">
									</div>
								</div>
								<div class="form-group m-form__group">
									<label>
										Invoice / DR No.:
									</label>
									<input type="text" name="invoice_dr_no" class="form-control m-input" data-validation="required" autocomplete="off">
								</div>
								<div class="form-group m-form__group">
									<label>
										Project Name:
									</label>
									<input type="text" name="project_name" class="form-control m-input" value="<?php echo strtoupper("One Comm South Hill"); ?>" data-validation="required" autocomplete="off">
								</div>
							</div>
							<div class="col-md-6">
								<!-- <div class="form-group m-form__group">
									<label>
										Reference No.:
									</label>
									<input type="text" name="reference_no" class="form-control m-input" readonly="readonly" value="<?php// echo $refgen;?>" data-validation="required">
								</div> -->
								<div class="form-group m-form__group">
									<label>
										Received Date:
									</label>
									<input type="text" name="received_date" readonly class="form-control m-input" data-validation="required" value="<?php echo date("m/d/Y H:i:s");?>">
								</div>
								<div class="form-group m-form__group">
									<label>
										PO No.:
									</label>
									<input type="text" name="po_no" class="form-control m-input" autocomplete="off">
								</div>
								<div class="form-group m-form__group">
									<label>
										Remarks
									</label>
									<textarea class="form-control m-input" name="remarks" rows="3"></textarea>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--end::Portlet-->
			<!--start:: Content Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Receiving Contents
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item">
								
							</li>
						</ul> 
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Form -->
					<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
						<div class="row">
							<div class="col-md-12">
								<table class="table table-striped table-bordered" id="table-receiving-contents" width="100%">
									<col width="15%">
									<col width="50%">
									<col width="10%">
									<col width="7%">
									<col width="10%">
									<col width="8%">
									<thead>
										<tr>
											<th>Stock Code</th>
											<th>Item Description</th>
											<th>Unit</th>
											<th>Qty</th>
											<th>Unit Price</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>	

									</tbody>
								</table>
							</div>
						</div>
					</div>	
				</div>
				<div class="m-portlet__foot">
					<div class="row align-items-center">
						<div class="col-lg-6 m--valign-middle">
							
						</div>
						<div class="col-lg-6 m--align-right">
							<button type="submit" class="btn btn-brand  btn-submit">
								Print
							</button>
							<button type="button" class="btn btn-danger btnCancel btn-cancel_transaction">Cancel</button>
						</div>
					</div>
				</div>
			</div>
			<!--end:: Content Portlet-->
		</form>
		<!--end: Form -->
		</div>
	</div>
</div>

<!-- Model Item Lookup Begin -->
<div class="modal fade" id="modal-item-lookup" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('receiving/add_receiving_content_temp'); ?>" method="POST" id="form-item-new">
			<div class="modal-header"><h5 class="modal-title">Add Item</h5>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="form-control-label">
						Search Item
					</label>
					<select class="form-control select2-hidden-accessible" tabindex="-1" data-validation="required" aria-hidden="true" name="item" style="width: 100% !important;" id="item-collection">
						<option disabled="disabled" selected="selected" value="">Select Item</option>
						<?php
							$itemCollection = $this->crud->getCollection(array(),"items");
							if($itemCollection):
								foreach($itemCollection as $_itemCollection):
									?>
										<option value="<?php echo $_itemCollection["id"];?>"><?php echo $_itemCollection["sku"] ." | ". $_itemCollection["name"];?></option>
									<?php
								endforeach; 
							endif;
						?>
					</select>
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Item Description
					</label>
					<input type="text" class="form-control m-input" disabled="disabled" name="name">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Stock Code
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="sku">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Unit
					</label>
					<input type="text" class="form-control m-input" disabled="disabled"  name="unit">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Quantity
					</label>
					<input type="number" class="form-control m-input" step="any" data-validation-allowing="float" name="qty" data-validation="required">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Unit Price
					</label>
					<input type="number" class="form-control m-input text-right" step="any" data-validation-allowing="float" name="unit_price" data-validation="required" placeholder="0.00">
				</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-success btnSave"data-dismiss="modal">Preview</button>
				<button type="submit" class="btn btn-primary btn-submit btnSave">Add</button>
			</div>
			</form>
		</div>
	</div>
</div>
<!-- Model Item Lookup End -->

<!-- Model Item Lookup Begin Edit -->
<div class="modal fade" id="_modalItemEdit" role="dialog" aria-hidden="true">
	<div class="modal-dialog modal-m" role="document">
		<div class="modal-content">
			<form action="<?php echo base_url('receiving/update_receiving_content_temp'); ?>" method="POST" id="form-item-edit">
				<input type="hidden" name="id" v-model="item_update.id">
			<div class="modal-header"><h5 class="modal-title">Update Item</h5>
			</div>
			<div class="modal-body">
				<div class="form-group ">
					<label class="form-control-label">
						Item Description
					</label>
					<input type="text" class="form-control m-input" v-model="item_update.name" disabled="disabled" name="name">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Stock Code
					</label>
					<input type="text" class="form-control m-input" v-model="item_update.sku" disabled="disabled"  name="sku">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Unit
					</label>
					<input type="text" class="form-control m-input" v-model="item_update.uom_code" disabled="disabled"  name="unit">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Quantity
					</label>
					<input type="number" class="form-control m-input"  name="qty" step="any"  data-validation-allowing="float" data-validation="required" v-model="item_update.qty">
				</div>
				<div class="form-group ">
					<label class="form-control-label">
						Unit Price
					</label>
					<input type="number" class="form-control m-input text-right" step="any" v-model="item_update.unit_price" data-validation-allowing="float" name="unit_price" data-validation="required" placeholder="0.00">
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">
					Cancel
			 	</button>
				<button type="button" class="btn btn-success btnCancel"data-dismiss="modal">Preview</button>
				<button type="submit" class="btn btn-primary btn-submit btnUpdate">Update</button>
			</div>
			</form>
		</div>
	</div>
</div>
<!-- Model Item Lookup End Edit -->

<script type="text/javascript">
var _currentActions = <?php echo json_encode($actions); ?>;
var _supplierList = [];
<?php if(isset($receivingSuppliers) && $receivingSuppliers): ?>
_supplierList = <?php echo json_encode($receivingSuppliers); ?>;
<?php endif; ?>
var _dtreceiving_contents = $("#table-receiving-contents").DataTable({
	dom: '<"toolbar">rt',
	serverSide: false,
	processing: true,
	ajax: {
		url: "<?php echo base_url("receiving/get_receiving_content_temp"); ?>",
		type: "post",
		dataType: "json",
	},columnDefs: [{
		targets: [ -1 ],
		orderable: false,
	},{
		targets: [ 4 ],
		className: "text-right",
	}
	]

	});
$("div.toolbar").css({ "margin-bottom": "5px" });
$("div.toolbar").html('<button type="button" class="m-portlet__nav-link btn m-btn--square btn-success btnNew"  data-toggle="modal" data-target="#modal-item-lookup"><i class="fa fa-plus"></i> Add Item </button>');


$("#inventory_item-new").on("click",function(){
	$("#modal-inventory_uom-new").modal("show");
});


$.validate({
	form : '#add_receving_form',
	lang: 'en',
	onSuccess : function(form) {
		var countRows = _dtreceiving_contents.rows()[0].length;
		if(countRows > 0){
			$.ajax({
				url: form[0].action,
				type: "POST",
				dataType: "json",
				data: $("#add_receving_form").find("input,textarea").serialize(),
				beforeSend: function(){
					$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
				},
				success: function(data){
					if(data.status){
						toastr.success(data.toastr_msg, "Receiving New", 5000);
						window.open("<?php echo site_url("inventory/printable/print_receiving_report"); ?>"+"/"+data.id, "_blank");
						setTimeout(function(){ window.location.href = "<?php echo site_url('receiving/index');?>"; }, 1000);
					}else{
						toastr.error(data.toastr_msg, "Error Receiving", 5000);
					}
					$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
				}
			});				
		}else{
			toastr.error("No item(s) found, please add items to proceed!", "Error Receiving", 5000);
		}
		return false;
	},
});

//select init
$('#item-collection').select2();

//init date time picker
	$('input[name=received_date]').datetimepicker({
		todayHighlight: true,
		autoclose: true,
		pickerPosition: 'bottom-left',
		todayBtn: true,
		format: 'mm/dd/yyyy hh:ii:ss'
	});

//select2 on select event
$('#item-collection').on('select2:select', function (e) { 
	var data = e.params.data;
	console.log(data.id);
	$.ajax({
		url: "<?php echo site_url('Receiving/get_item_data');?>",
		type: "POST",
		data: {id : data.id},
		success: function(data){
			$("input[name=name]").val(data.name);
			$("input[name=sku]").val(data.sku);
			$("input[name=unit]").val(data.uom_code);
			
		}
	});
});

// add item validate
$.validate({
	form : '#form-item-new',
	lang: 'en',
	onSuccess : function(form) {
		$.ajax({
			url: form[0].action,
			type: "POST",
			dataType: "json",
			data: $("#form-item-new").serialize(),
			beforeSend: function(){
				$(".btn-submit").addClass("m-btn--custom m-loader m-loader--light m-loader--right");
			},
			success: function(data){
				if(data.status){
					toastr.success(data.toastr_msg, "Item has been added", 5000);
					$("#form-item-new").trigger("reset");
					$("#item-collection").val('').trigger('change');
				}else{
					toastr.error(data.toastr_msg, "Error inventory item", 5000);
				}
				$(".btn-submit").removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
				_dtreceiving_contents.ajax.reload();
			}
		});
		return false;
	},
});

//open edit content item
$("#table-receiving-contents").on("click", ".btnEditItem", function(){
	var _dataId = $(this).data("id");
	
	$.ajax({
		url: "<?php echo site_url("receiving/get_item"); ?>",
		type: "post",
		dataType: "json",
		data: { id: _dataId },
		success: function(json){
			if(json){
				vm.item_update = json.value;
			}else{
				toastr.error(json.toastr_msg, "Error Units Data", 5000);
			}
		}
	});	
});

var _items = { id: 0, name: "", sku: "", uom_code: "", qty: "" };
var vm = new Vue({
	el: "#form-item-edit",
	data: {	item_update: _items },
	mounted: function(){
		$.validate({
			form : '#form-item-edit',
			lang: 'en',
			onSuccess : function(form) {
				var _url = form[0].action;
				var _data = jQuery(form[0]).serialize();
				var _btnSubmit = $(form[0]).find(".btn-submit");
				
				$.ajax({
					url: _url,
					type: "POST",
					data: _data,
					beforeSend: function(){
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.addClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					},
					success: function(data){
						if(data.status){
							toastr.success(data.toastr_msg, "Update units", 5000);
							/*** _modalItemEdit.modal("hide");
							setTimeout(function(){ _dtTable.ajax.reload(); }, 500); ***/
							
							_btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right");
							_dtreceiving_contents.ajax.reload();
						}else{
							toastr.error(data.toastr_msg, "Error units", 5000);
						}
						if(typeof _btnSubmit !== "undefined"){ _btnSubmit.removeClass("m-btn--custom m-loader m-loader--light m-loader--right"); }
					}
				});
				
				return false;
			}
		});
	}
});

//remove item content temp
$("#table-receiving-contents").on("click",".btnRemoveItem", function(){
	var id = $(this).attr("data-id");

	$.ajax({
		url: "<?php echo site_url('receiving/remove_item_content_temp');?>",
		type: "POST",
		dataType: "json",
		data: { id : id},
		success: function(data){
			if(data.status){
				toastr.success(data.toastr_msg, "Item has been removed.", 5000);
				_dtreceiving_contents.ajax.reload();
			}else{
				toastr.error(data.toastr_msg, "Error inventory item", 5000);
			}
		}
	});
});

//cancel transaction
jQuery(document).on("click", ".btn-cancel_transaction", function(){
	window.location.href = "<?php echo site_url("receiving/index"); ?>";
});

jQuery(document).ready(function(){
	supplierTypeHead();
	$("#item-collection").select2({ placeholder: "Select Item"});
});

var supplierTypeHead = function() {
	var substringMatcher = function(strs) {
		return function findMatches(q, cb) {
			var matches, substringRegex;
			matches = [];
			substrRegex = new RegExp(q, 'i');
			$.each(strs, function(i, str) {
				if (substrRegex.test(str)) {
					matches.push(str);
				}
			});

			cb(matches);
		};
	};

	$('#m_typeahead_1').typeahead({
		hint: false,
		highlight: true,
		minLength: 1
	}, {
		name: 'supplier',
		source: substringMatcher(_supplierList)
	});
}
</script>
<style>
.tt-menu { width: 100%; }
</style>