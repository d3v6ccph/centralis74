<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Receiving_model extends CI_Model{
	protected $receivingTable = "receiving";
	
	function __construct(){
		parent::__construct();
		$this->load->model("access_control_model", "acl_model");
		$this->load->model("datatable_model","dt_model");
	}

	function getReceivingList(){
		$post = $this->input->post();
		if($post){
			$columns = array("id", "reference_no", "supplier", "invoice_dr_no", "received_date", "created_by");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable("receiving");
			
			$dtInventoryItems->setParameterFields($columns);
			$whereParams = array();
			$whereParams["status"] = 1;
			$dtInventoryItems->setWhereParameters($whereParams);
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$userData = $this->core_layout->getUserData($pst->created_by);
					$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
					
					$nestedData['id'] = $pst->id;
					$nestedData['reference_no'] = $pst->reference_no;
					$nestedData['invoice_dr_no'] = $pst->invoice_dr_no;
					$nestedData['supplier'] = $pst->supplier;
					$nestedData['received_date'] = $pst->received_date != "0000-00-00 00:00:00" ? date("m/d/Y", strtotime($pst->received_date)) : "--";
					$nestedData['received_time'] = $pst->received_date != "0000-00-00 00:00:00" ? date("H:i", strtotime($pst->received_date)) : "--";
					$nestedData['created_by'] = $displayName;
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}

	function getItemData($post = array()){
		$query = $this->db->query("SELECT items.id,items.name,items.sku,items.qty,uom.uom_code FROM items LEFT JOIN uom ON items.unit = uom.id WHERE items.id = {$post['id']}");
		if($query->num_rows() == 1){
			$row = $query->row_array();
			$row["uom_code"] = strtoupper($row["uom_code"]);
			return $row;
		}else{
			return false;
		}
	}

	function getReceivingContentTemp(){
		$userData = $this->session->userdata();
		$resultarray = array();
		$query = $this->db->query("SELECT receiving_contents_temp.id,receiving_contents_temp.qty,FORMAT(receiving_contents_temp.unit_price,2) as unit_price,items.name,items.sku,uom.uom_code FROM ((receiving_contents_temp INNER JOIN items ON receiving_contents_temp.item = items.id) LEFT JOIN uom ON uom.id = items.unit) WHERE receiving_contents_temp.logged_id = {$userData["logged_in"]["id"]}");

		if($query){
			foreach($query->result_array() as $_query){
				$data = array();
				$data[] = strtoupper($_query["sku"]);
				$data[] = strtoupper($_query["name"]);
				$data[] = strtoupper($_query["uom_code"]);
				$data[] = $_query["qty"];
				$data[] = strtoupper($_query["unit_price"]);
				$data[] = "<button type='button' data-toggle='modal' data-target='#_modalItemEdit' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnEditItem' data-id='".$_query["id"]."'><i class='la la-edit'></i></button> <button type='button' class='btn btn-default m-btn m-btn--hover-danger m-btn--icon m-btn--icon-only m-btn--pill btnRemoveItem' data-id='".$_query["id"]."'><i class='la la-trash'></i></button>";

				$resultarray[] = $data;
			}
		}
		return array("data"=>$resultarray);
	}

	function getReceivingContent($post = array()){
		$resultarray = array();
		$query = $this->db->query("SELECT receiving_contents.id,receiving_contents.qty,receiving_contents.unit_price,receiving_contents.qty * receiving_contents.unit_price as amount,items.name,items.sku,uom.uom_code FROM ((receiving_contents INNER JOIN items ON receiving_contents.item = items.id) LEFT JOIN uom ON uom.id = items.unit) WHERE receiving_contents.receiving_id = {$post['id']}");

		if($query){
			foreach($query->result_array() as $_query){
				$data = array();
				$data[] = strtoupper($_query["sku"]);
				$data[] = strtoupper($_query["name"]);
				$data[] = strtoupper($_query["uom_code"]);
				$data[] = $_query["qty"];
				$data[] = $_query["unit_price"];
				$data[] = $_query["amount"];
				$data[] = "";

				$resultarray[] = $data;
			}
		}
		return array("data"=>$resultarray);
	}

	function saveReceiving($post = array()){
		$userData = $this->session->userdata();
		$resultarray = array();
		$post = $this->input->post();
		$session = $this->core_layout->getCurrentSession();
		$post["created_by"] = $session["emp_id"];
		$post["received_date"] = date("Y-m-d H:i:00", strtotime($post["received_date"]));
		$post["supplier"] = strtoupper($post["supplier"]);
		$post["project_name"] = strtoupper($post["project_name"]);
		$post["invoice_dr_no"] = strtoupper($post["invoice_dr_no"]);
		$post["po_no"] = strtoupper($post["po_no"]);
		$post["remarks"] = strtoupper($post["remarks"]);
		$post["reference_no"] = $this->getrefGen();
		
		$query = $this->db->insert("receiving", $post);
		$r_id = $this->db->insert_id();
		$receiving_id = $this->db->insert_id();
		$getContentTemp = $this->db->get_where('receiving_contents_temp',array("logged_id"=>$userData["logged_in"]["id"])); 
		if($query){
			foreach($getContentTemp->result_array() as $_getContentTemp){
				$this->db->insert("receiving_contents",array('receiving_id'=>$receiving_id,"item"=>$_getContentTemp["item"],"qty"=>$_getContentTemp["qty"],"unit_price"=>$_getContentTemp["unit_price"]));
				$this->updateItem(array("qty"=>$_getContentTemp["qty"],"item"=>$_getContentTemp["item"]));

				$this->db->delete('receiving_contents_temp', array('id' => $_getContentTemp['id'])); 
			}
			//$this->db->query("TRUNCATE TABLE receiving_contents_temp");
			$resultarray["status"] = TRUE;
			$resultarray["toastr_msg"] = "Data successfully saved.";
			$resultarray["id"] = $r_id;
		}else{
			$resultarray["status"] = FALSE;
			$resultarray["toastr_msg"] = "Error processing request.";
		}

		return $resultarray;
	}

	function updateItem($data = array()){
		$qty = 0;
		$getItemQty = $this->db->query("SELECT qty FROM items WHERE id = {$data['item']}");
		$itemData = $getItemQty->row_array();
		$qty = (float)$itemData["qty"] + (float)$data["qty"];

		$this->db->set(array("qty"=>$qty));
		$this->db->where(array("id"=>$data["item"]));
		$query = $this->db->update("items");

		return $query ? true : false;
	}

	function getReceiving($post = array()){
		$query = $this->db->get_where('receiving', $post);
		return $query ? $query->row_array() : false;
	}

	function addReceivingContentTemp(){
		$userData = $this->session->userdata();
		$resultarray = array();
		$post = $this->input->post();
		$post["logged_id"] = $userData["logged_in"]["id"];
		// $checkItemifSelected = $this->checkItemifSelected($post["item"]);
		// if($checkItemifSelected){
			$query = $this->crud->insert(array("item"=>$post["item"],"qty"=>$post["qty"],"unit_price"=>$post["unit_price"],"logged_id"=>$post["logged_id"]),"receiving_contents_temp");
			if($query){
				$resultarray["toastr_msg"] = "Item successfully added.";
				$resultarray["status"] = TRUE;
			}else{
				$resultarray["toastr_msg"] = "Error received item.";
				$resultarray["status"] = FALSE;
			}
		// }else{
		// 	$resultarray["toastr_msg"] = "Item Already Selected.";
		// 	$resultarray["status"] = FALSE;
		// }

		return $resultarray;
	}

	function checkItemifSelected($item = NULL){
		if($item){
			$query = $this->db->query("SELECT * FROM receiving_contents_temp WHERE item = {$item}");
			return $query->num_rows() == 0 ? true : false;
		}

	}

	function removeItemContentTemp(){
		$resultarray = array();
		$post = $this->input->post();
		$query = $this->db->delete("receiving_contents_temp",$post);
		if($query){
			$resultarray["toastr_msg"] = "Item successfully removed.";
			$resultarray["status"] = TRUE;
		}else{
			$resultarray["toastr_msg"] = "Error received item.";
			$resultarray["status"] = FALSE;
		}
		return $resultarray;
	}

	function getItem(){
		$post = $this->input->post();
		$resultarray = array();
		$query = $this->db->query("SELECT receiving_contents_temp.id,receiving_contents_temp.qty,receiving_contents_temp.unit_price,items.name,items.sku,uom.uom_code FROM ((receiving_contents_temp INNER JOIN items ON receiving_contents_temp.item = items.id) LEFT JOIN uom ON uom.id = items.unit) WHERE receiving_contents_temp.id = {$post['id']}");

		if($query){
			$resultarray["response"] = TRUE;
			$resultarray["value"] = $query->row_array();
		}else{
			$resultarray["response"] = FALSE;
			$resultarray["value"] = "Error processing request.";
		}

		return $resultarray;
	}

	function updateReceivingContentTemp(){
		$post = $this->input->post();
		$resultarray = array();

		$this->db->set(array("qty"=>$post["qty"],"unit_price"=>$post["unit_price"]));
		$this->db->where(array("id"=>$post["id"]));
		$query = $this->db->update("receiving_contents_temp");

		if($query){
			$resultarray["toastr_msg"] = "Item successfully updated.";
			$resultarray["status"] = TRUE;
		}else{
			$resultarray["toastr_msg"] = "Error updating item.";
			$resultarray["status"] = FALSE;
		}

		return $resultarray;
	}
	
	function getAllSuppliers(){
		$arrData = array();
		$this->db->select("supplier");
		$this->db->from("receiving");
		$this->db->order_by("supplier", "ASC");
		$this->db->group_by("supplier");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$arrData[] = $rs->supplier;
			}
		}
		
		return $arrData;
	}

	function getReceivingContentById($receiving_id = NULL){
		$query = $this->db->query("SELECT * FROM receiving_contents WHERE receiving_id = {$receiving_id}");
		return $query ? $query->result_array() : NULL;
	}

	function cancelReceiving(){
		$post = $this->input->post();
		$resultset = array();
		if($post){
			$session = $this->core_layout->getCurrentSession();
			
			$where = array();
			$where["id"] = $post["id"];
			
			$data = array();
			$data["status"] = 0;
			$data["cancel_remarks"] = $post["cancel_remarks"];
			$data["cancelled_by"] = $session["emp_id"];
			$data["cancelled_at"] = date("Y-m-d H:i:s");
			
			$update = $this->db->update($this->receivingTable, $data, $where);
			if($update){
				$resultset["response"] = true;
				$resultset["toastr_msg"] = "Receiving Report has been cancelled.";
			}else{
				$resultset["response"] = false;
				$resultset["toastr_msg"] = "Failed to cancel receiving report";
			}
		}else{
			$resultset["response"] = false;			
			$resultset["toastr_msg"] = "No data found!";
		}
		
		return $resultset;
	}

	function getrefGen(){
		$countData = $this->db->count_all_results('receiving');
		$countData = $countData + 1;
		$coreData = $this->settings->getSettingsData();
		$siteCode = (isset($coreData->site_code) && $coreData->site_code)? strtoupper($coreData->site_code):"";
		$countData = str_pad($countData, 5, '0', STR_PAD_LEFT);
		$refgen = ($siteCode)? "RR-{$siteCode}-{$countData}":"RR-{$countData}";

		return $refgen;
	}

	function getReceivingArchives(){
		$post = $this->input->post();
		if($post){
			$columns = array("id", "reference_no", "supplier", "invoice_dr_no", "received_date", "created_by","status","cancelled_by","cancelled_at","cancel_remarks");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable("receiving");
			
			$dtInventoryItems->setParameterFields($columns);
			$whereParams = array();
			$whereParams["status"] = 0;
			$dtInventoryItems->setWhereParameters($whereParams);
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$userData = $this->core_layout->getUserData($pst->cancelled_by);
					$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
					
					$nestedData['id'] = $pst->id;
					$nestedData['reference_no'] = $pst->reference_no;
					$nestedData['supplier'] = $pst->supplier;
					$nestedData['cancelled_date'] = $pst->cancelled_at != "0000-00-00 00:00:00" ? date("m/d/Y", strtotime($pst->cancelled_at)) : "--";
					$nestedData['cancelled_time'] = $pst->cancelled_at != "0000-00-00 00:00:00" ? date("H:i", strtotime($pst->cancelled_at)) : "--";
					$nestedData['cancelled_by'] = $displayName;
					$nestedData['cancel_remarks'] = $pst->cancel_remarks;
					$nestedData['btn'] = "<button type='button' title='View Transaction' class='btn btn-default m-btn m-btn--hover-accent m-btn--icon m-btn--icon-only m-btn--pill btnViewarchivedContents' data-id='".$pst->id."'><i class='la 	la-file-text'></i></button>";
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}

}