<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends MY_Controller {
	protected $startWeek = "";
	protected $endWeek = "";
	protected $startMonth = "";
	protected $endMonth = "";
	
	function __construct(){
		parent::__construct();
		$this->authenticate->doRedirect();
		$this->core_layout->setBodyClass("dashboard");
		$this->core_layout->setPrivilegeName("dashboard");
		
		$this->startWeek = date("Y-m-d", strtotime("monday this week"));
		$this->endWeek = date("Y-m-d", strtotime("sunday this week"));
		
		$this->startMonth = date("Y-m-1");
		$this->endMonth = date("Y-m-t");
		
		date_default_timezone_set('Asia/Manila');
	}
	public function index(){
		$receivedToday = $this->getReceivedItemToday();
		$issuedToday = $this->getIssuedItemToday();
		
		$receivedWeekly = $this->getReceivedItemWeekly();
		$issuedWeekly = $this->getIssuedItemWeekly();
		
		$receivedMonthly = $this->getReceivedItemMonthly();
		$issuedMonthly = $this->getIssuedItemMonthly();
		
		$arrData = array();
		$arrData["received_today"] = $receivedToday;
		$arrData["issued_today"] = $issuedToday;
		
		$arrData["received_weekly"] = $receivedWeekly;
		$arrData["issued_weekly"] = $issuedWeekly;
		
		$arrData["received_monthly"] = $receivedMonthly;
		$arrData["issued_monthly"] = $issuedMonthly;
		
		$this->load->view('core/templates/header');
		$this->load->view('index', $arrData);
		$this->load->view('core/templates/footer');
	}
	
	function getReceivedItemToday(){
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku");
		$this->db->from("receiving_contents a");
		$this->db->join("receiving b", "b.id = a.receiving_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->like("b.created_at", $dateToday);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
	
	function getIssuedItemToday(){
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku, d.name as contractor");
		$this->db->from("issuance_contents a");
		$this->db->join("issuance b", "b.id = a.issuance_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->join("contractors d", "d.id = b.issued_to", "left");
		$this->db->like("b.created_at", $dateToday);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
	
	function getReceivedItemWeekly(){
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku");
		$this->db->from("receiving_contents a");
		$this->db->join("receiving b", "b.id = a.receiving_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->where("b.created_at >=", $this->startWeek);
		$this->db->where("b.created_at <=", $this->endWeek);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
	
	function getIssuedItemWeekly(){
		
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku, d.name as contractor");
		$this->db->from("issuance_contents a");
		$this->db->join("issuance b", "b.id = a.issuance_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->join("contractors d", "d.id = b.issued_to", "left");
		$this->db->where("b.created_at >=", $this->startWeek);
		$this->db->where("b.created_at <=", $this->endWeek);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
	
	function getReceivedItemMonthly(){
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku");
		$this->db->from("receiving_contents a");
		$this->db->join("receiving b", "b.id = a.receiving_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->where("b.created_at >=", $this->startMonth);
		$this->db->where("b.created_at <=", $this->endMonth);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
	
	function getIssuedItemMonthly(){
		
		$arrData = array();
		$dateToday = date("Y-m-d");
		$this->db->select("a.qty, b.*, c.name, c.sku, d.name as contractor");
		$this->db->from("issuance_contents a");
		$this->db->join("issuance b", "b.id = a.issuance_id", "left");
		$this->db->join("items c", "c.id = a.item", "left");
		$this->db->join("contractors d", "d.id = b.issued_to", "left");
		$this->db->where("b.created_at >=", $this->startMonth);
		$this->db->where("b.created_at <=", $this->endMonth);
		$this->db->order_by("b.created_at", "DESC");
		$query = $this->db->get();
		
		if($query->num_rows() > 0){
			foreach($query->result() as $rs){
				$userData = $this->core_layout->getUserData($rs->created_by);
				$displayName = (isset($userData["display_name_1"]) && $userData["display_name_1"])? $userData["display_name_1"]: "---";
				$rs->created_by = $displayName;
				$arrData[] = $rs;
			}
		}
		
		return $arrData;
	}
}
