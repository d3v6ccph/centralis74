<div class="m-content">
	<div class="row">
		<div class="col-md-6 col-lg-6">
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">RECEIVED ITEMS</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="nav nav-pills nav-pills--brand m-nav-pills--align-right m-nav-pills--btn-pill m-nav-pills--btn-sm" role="tablist">
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link active" data-toggle="tab" href="#m_widget_receiving_tab1_content" role="tab">
									Today
								</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_widget_receiving_tab2_content" role="tab">
									Week
								</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_widget_receiving_tab3_content" role="tab">
									Month
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<div class="tab-content">
						<div class="tab-pane active" id="m_widget_receiving_tab1_content">
						<?php if(isset($received_today) && $received_today): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($received_today as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--primary">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been received from 
											<strong class="m--font-primary"><?php echo $item->supplier; ?></strong>
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-primary alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Received Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
						<div class="tab-pane" id="m_widget_receiving_tab2_content">
						<?php if(isset($received_weekly) && $received_weekly): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($received_weekly as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--primary">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been received from 
											<strong class="m--font-primary"><?php echo $item->supplier; ?></strong>
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-primary alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Received Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
						<div class="tab-pane" id="m_widget_receiving_tab3_content">
						<?php if(isset($received_monthly) && $received_monthly): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($received_monthly as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--primary">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been received from 
											<strong class="m--font-primary"><?php echo $item->supplier; ?></strong>
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-primary alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Received Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6 col-lg-6">
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">ISSUED ITEMS</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="nav nav-pills nav-pills--brand m-nav-pills--align-right m-nav-pills--btn-pill m-nav-pills--btn-sm" role="tablist">
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link active" data-toggle="tab" href="#m_widget_issuance_tab1_content" role="tab">
									Today
								</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_widget_issuance_tab2_content" role="tab">
									Week
								</a>
							</li>
							<li class="nav-item m-tabs__item">
								<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_widget_issuance_tab3_content" role="tab">
									Month
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<div class="tab-content">
						<div class="tab-pane active" id="m_widget_issuance_tab1_content">
						<?php if(isset($issued_today) && $issued_today): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($issued_today as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--danger">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been issued to 
											<strong class="m--font-primary"><?php echo $item->contractor; ?></strong> 
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-danger alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Issued Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
						<div class="tab-pane" id="m_widget_issuance_tab2_content">
						<?php if(isset($issued_weekly) && $issued_weekly): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($issued_weekly as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--danger">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been issued to 
											<strong class="m--font-primary"><?php echo $item->contractor; ?></strong> 
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-danger alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Issued Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
						<div class="tab-pane" id="m_widget_issuance_tab3_content">
						<?php if(isset($issued_monthly) && $issued_monthly): ?>
						<div class="m-scrollable mCustomScrollbar _mCS_3 mCS-autoHide" data-scrollable="true" data-max-height="400">
							<?php foreach($issued_monthly as $item): ?>
							<div class="m-widget2">
								<div class="m-widget2__item m-widget2__item--danger">
									<div class="m-widget2__checkbox">&nbsp;</div>
									<div class="m-widget2__desc">
										<p class="m-widget2__text text-justify" style="margin: 0;">
											An item <?php echo "{$item->sku} {$item->name}"; ?> has been issued to 
											<strong class="m--font-primary"><?php echo $item->contractor; ?></strong> 
											with REFERENCE # <?php echo $item->reference_no; ?>
										</p>
										<span class="m-widget2__user-name"><small><strong class="m--font-success"><?php echo $item->created_by; ?></strong></small></span>
										<span class="m-widget2__user-created_date pull-right"><small><strong class="m--font-danger"><?php echo date("F d, Y h:i A", strtotime($item->created_at)); ?></strong></small></span>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
						<?php else: ?>
							<div class="m-alert m-alert--icon m-alert--icon-solid m-alert--outline alert alert-danger alert-dismissible fade show" role="alert">
								<div class="m-alert__icon">
									<i class="flaticon-exclamation-1"></i>
									<span></span>
								</div>
								<div class="m-alert__text">
									<strong>No Issued Items!</strong> as of today (<?php echo date("F d, Y h:i A"); ?>)
								</div>
							</div>
						<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>