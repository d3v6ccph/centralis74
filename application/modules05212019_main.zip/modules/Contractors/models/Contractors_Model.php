<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Contractors_model extends CI_Model{
	protected $contractorTable = "contractors";
	function __construct(){
		parent::__construct();
		$this->load->model("access_control_model", "acl_model");
		$this->load->model("datatable_model","dt_model");
	}

	function getContractorsList(){
		$post = $this->input->post();
		if($post){
			$columns = array("id", "name", "status");
			$dir = $post["order"][0]["dir"];
			$order = $columns[$post["order"][0]["column"]];
			$draw = (isset($post['draw']) && $post['draw'])? $post['draw']: 0;
			$start = (isset($post["start"]) && $post["start"])? $post["start"]: 0;
			$limit = (isset($post["length"]) && $post["length"])? $post["length"]: 0;
			$searchValue = (isset($post["search"]["value"]) && $post["search"]["value"])? $post["search"]["value"]: "";
			$dtInventoryItems = $this->dt_model->dataTable();
			$dtInventoryItems->setTable("contractors");
			
			$dtInventoryItems->setParameterFields($columns);
			
			$parameters = array();
			$parameters["status !="] = 2;
			
			$dtInventoryItems->setWhereParameters($parameters);
			
			$totalData = $dtInventoryItems->dtAllPostsCount();
			$totalFiltered = $totalData;
			
			if(empty($searchValue)){            
				$posts = $dtInventoryItems->dtAllPosts($limit, $start, $order, $dir);
			}else {
				$posts = $dtInventoryItems->dtSearch($limit, $start, $searchValue, $order, $dir);
				$totalFiltered = $dtInventoryItems->dtPostSearchCount($searchValue);
			}
			
			$data = array();
			if(!empty($posts)){
				foreach ($posts as $pst){
					$status = "";
					switch($pst->status):
						case 2: $status = '<span class="btn btn-danger m-btn m-btn--icon m-btn--icon-only btn-sm"><i class="la la-user-times"></i></span>'; break;
						case 1: $status = '<span class="btn btn-info m-btn m-btn--icon m-btn--icon-only btn-sm"><i class="la la-user"></i></span>'; break;
						default: $status = '<span class="btn btn-danger m-btn m-btn--icon m-btn--icon-only btn-sm"><i class="la la-user"></i></span>'; break;
					endswitch;
				
					$nestedData['id'] = $pst->id;
					$nestedData['name'] = $pst->name;
					$nestedData['status'] = $status;
					$data[] = $nestedData;
				}
			}
			$json_data = array(
                    "draw" => intval($draw),  
                    "recordsTotal" => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data,   
                    );
            
			return $json_data;
		}else{
			return array(
				"draw"=>1,
				"recordsTotal"=>0,
				"recordsFiltered"=>0,
				"data"=>array(),
				);
		}
	}

	function archiveContractor(){
		$resultset = array();
		$post = $this->input->post();
		if($post){
			$data = array();
			$data["status"] = 2;
			$archive = $this->db->update($this->contractorTable, $data, $post);
			if($archive){
				$resultset["response"] = true;
				$resultset["toastr_msg"] = "Contractor has been removed.";
			}else{
				$resultset["response"] = false;				
				$resultset["toastr_msg"] = "Failed to remove contractor!";
			}
		}else{
			$resultset["response"] = false;
			$resultset["toastr_msg"] = "Failed to remove contractor, no data found!";
		}
		return $resultset;
	}
	function updateContractor(){
		$resultset = array();
		$post = $this->input->post();
		if($post){
			$where = array();
			$where["id"] = $post["id"];
			unset($post["id"]);
			
			$update = $this->db->update($this->contractorTable, $post, $where);
			if($update){
				$resultset["response"] = true;
				$resultset["toastr_msg"] = "Contractor data has been updated.";
			}else{
				$resultset["response"] = false;
				$resultset["toastr_msg"] = "Failed to update contractor data!";
			}
		}else{
			$resultset["response"] = false;			
			$resultset["toastr_msg"] = "No data found!";
		}
		
		return $resultset;
	}
	function addContractor(){
		$post = $this->input->post();
		$resultarray = array();
		$query = $this->db->insert("contractors", $post);

		if($query){
			$resultarray["response"] = TRUE;
			$resultarray["toastr_msg"] = "Contractor successfully saved!";
		}else{
			$resultarray["response"] = FALSE;
			$resultarray["toastr_msg"] = "Error processing request.";
		}

		return $resultarray;
	}
	
	function getContractorData(){
		$resultset = array();
		$post = $this->input->post();
		if($post){
			$query = $this->db->get_where($this->contractorTable, $post);
			if($query->num_rows() == 1){
				$row = $query->row();
				$resultset["value"] = $row;
				$resultset["response"] = true;
			}else{
				$resultset["response"] = false;
			}
		}else{
			$resultset["response"] = false;			
		}
		
		return $resultset;
	}

	function getContractorsName(){
		$query = $this->db->query("SELECT * FROM contractors");
		return $query;
	}

}