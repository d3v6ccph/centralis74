<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Reports extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->core_layout->addJs("plugins/daterange_picker/daterangepicker.min.js");
		$this->core_layout->addCss("plugins/daterange_picker/daterangepicker.css");

		$this->load->model("Inventory/Items_model","items_model");
		$this->load->model("Contractors/Contractors_model","contractors_model");
		
	}
	public function index(){
		$this->load->view('core/templates/header');
		$this->load->view('index');
		$this->load->view('core/templates/footer');
	}
	
	public function inventory_report(){
		$this->core_layout->setPageTitle("Reports - Inventory Report");
		$this->core_layout->setBodyClass("reports inventory_report");
		$this->core_layout->setPrivilegeName("inventory_report");
		$this->load->view('core/templates/header');
		$this->load->view('inventory/index');
		$this->load->view('core/templates/footer');
	}
	
	public function issuance_report(){
		$this->core_layout->setPageTitle("Reports - Issuance Report");
		$this->core_layout->setBodyClass("reports issuance_report");
		$this->core_layout->setPrivilegeName("issuance_report");
		$this->load->view('core/templates/header');
		$this->load->view('issuance/index');
		$this->load->view('core/templates/footer');
	}
	
	public function receiving_report(){
		$this->core_layout->setPageTitle("Reports - Receiving Report");
		$this->core_layout->setBodyClass("reports receiving_report");
		$this->core_layout->setPrivilegeName("receiving_report");
		$this->load->view('core/templates/header');
		$this->load->view('receiving/index');
		$this->load->view('core/templates/footer');
	}

	function get_item_list(){
		$data = $this->items_model->getInventoryData();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function issuance_data(){
		$data = $this->items_model->getIssuanceItems();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function receiving_data(){
		$resultset = array();
		$resultset = $this->items_model->getReceiveItems();
		
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($resultset));
	}
}
