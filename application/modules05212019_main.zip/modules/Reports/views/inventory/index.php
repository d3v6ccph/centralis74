<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Inventory Report
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item"></li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-inventory_report" width="100%">
								<thead>
									<tr>
										<th>STOCK CODE</th>
										<th>ITEM DESCRIPTION</th>
										<th>UNIT</th>
										<th>IN</th>
										<th>OUT</th>
										<th>BALANCE</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Search Issuance Data :: Start -->
<div class="modal fade" id="m_daterangepicker_modal" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="">
					Search Inventory Data
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true" class="la la-remove"></span>
				</button>
			</div>
			<form class="m-form m-form--fit m-form--label-align-right" id="form_searchdate" action="<?php echo site_url("reports/inventory_data")?>" method="POST">
				<div class="modal-body">
					<div class="form-group">
						<label class="form-control-label">Select Date Range</label>
						<input type="text" name="daterange" class="form-control" id="m_daterangepicker_1_modal" readonly="" placeholder="Select time">
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-secondary m-btn" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-brand m-btn btnAdvance_search" onclick="searchrange()">
						Search
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Search Attendance Data :: End -->
<script type="text/javascript">
var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";
var _dtTable = $("#table-inventory_report").DataTable({
	dom: 'B<"#irToolbar.toolbar">frtlip',
	serverSide: true,
	processing: true,
	ajax: {
		url: "<?php echo base_url("reports/get_item_list"); ?>",
		type: "post",
		dataType: "json",
		data: { _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "sku", width: "15%" },
		{ data: "name", width: "25%" },
		{ data: "uom_code", width: "15%" },
		{ data: "inventoryIn", width: "15%", className: "text-right"},
		{ data: "inventoryOut", width: "15%", className: "text-right"},
		{ data: "balance", width: "15%", className: "text-right"},
	], columnDefs: [{ 
		targets: "_all", 
		defaultContent: "", 
	}],
	pageLength: 0,
	lengthMenu: [ [10, 20, 50, 100, 200, 500, -1], [10, 20, 50, 100, 200, 500, "All"] ],
	buttons: [{
			extend: 'pdfHtml5',
			title: "INVENTORY REPORT as of "+"<?php echo date("F d, Y")?>",
			orientation: 'portrait',
			pageSize: 'LEGAL',
			className: 'btnPdfAction',
			customize: function(doc){
				var rowCount = doc.content[1].table.body.length;
				for (i = 1; i < rowCount; i++) {
					doc.content[1].table.body[i][3].alignment = 'right';
					doc.content[1].table.body[i][4].alignment = 'right';
					doc.content[1].table.body[i][5].alignment = 'right';
				}
			}
		},{
	        extend: 'excelHtml5',
	        title: "INVENTORY REPORT as of "+"<?php echo date("F d, Y")?>",
			className: 'btnExcelAction',
	}],
	initComplete: function(settings, json){
		$(".btnPdfAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".btnExcelAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".dt-buttons").appendTo("div#irToolbar");
		btnAction();
	}
});

var searchrange = function(){
	var form_searchdate = $("#form_searchdate");
	$.ajax({
		url: form_searchdate.attr("action"),
		type: "POST",
		dataType: "json",
		data: form_searchdate.serialize(),
		beforeSend: function()
		{
			mApp.blockPage({
				overlayColor: '#000000',
				type: 'loader',
				state: 'primary',
				message: 'Please wait...',
			});

			$(".blockUI.blockMsg .m-blockui").removeAttr("style");
			$(".blockUI.blockMsg.blockPage").css("z-index","2000");


		},
		success: function(json){
			_dtTable.clear();
			_dtTable.rows.add(json.data).draw();
			$('#m_daterangepicker_modal').modal('hide');
			mApp.unblockPage();

		}
	});
}

$('#m_daterangepicker_1_modal').daterangepicker({
	buttonClasses: 'm-btn btn',
	applyClass: 'btn-primary',
	cancelClass: 'btn-secondary'
});

function btnAction(){
	var dtCount = _dtTable.data().count();

	if(dtCount == 0){
		$(".buttons-pdf").attr("disabled","disabled");
		$(".buttons-excel").attr("disabled","disabled");
	}else{
		$(".buttons-pdf").removeAttr("disabled");
		$(".buttons-excel").removeAttr("disabled");
	}
}
</script>