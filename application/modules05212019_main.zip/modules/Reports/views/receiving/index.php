<div class="m-content">
	<div class="row">
		<div class="col-lg-12">
			<!--begin::Portlet-->
			<div class="m-portlet m-portlet--mobile">
				<div class="m-portlet__head">
					<div class="m-portlet__head-caption">
						<div class="m-portlet__head-title">
							<h3 class="m-portlet__head-text">
								Receiving Report
							</h3>
						</div>
					</div>
					<div class="m-portlet__head-tools">
						<ul class="m-portlet__nav">
							<li class="m-portlet__nav-item"></li>
						</ul>
					</div>
				</div>
				<div class="m-portlet__body">
					<!--begin: Datatable -->
						<div class="m_datatable m-datatable m-datatable--default m-datatable--loaded m-datatable--scroll">
							<table class="table table-striped table-bordered" id="table-receiving_report" width="100%">
								<thead>
									<tr>
										<th>REFERENCE #</th>
										<th>STOCK CODE</th>
										<th>ITEM DESCRIPTION</th>
										<th>UNIT</th>
										<th>QTY</th>
										<th>DATE RECEIVED</th>
									</tr>
								</thead>
								<tbody>	
								</tbody>
							</table>
						</div>
					<!--end: Datatable -->
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Search Issuance Data :: Start -->
<div class="modal fade" id="m_daterangepicker_modal" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="">
					Search Receiving Data
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true" class="la la-remove"></span>
				</button>
			</div>
			<form class="m-form m-form--fit m-form--label-align-right" id="form_searchdate" action="<?php echo site_url("reports/receiving_data")?>" method="POST">
				<div class="modal-body">
					<div class="form-group">
						<label class="form-control-label">Select Date Range</label>
						<input type="text" name="daterange" class="form-control" id="m_daterangepicker_1_modal" readonly="" placeholder="Select time">
					</div>
				</div>
				<div class="modal-footer">
					<button class="btn btn-secondary m-btn" data-dismiss="modal">Close</button>
					<button type="button" class="btn btn-brand m-btn btnAdvance_search" onclick="searchrange()">
						Search
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Search Attendance Data :: End -->
<script type="text/javascript">
// init date range picker
m_startDate = "";
m_endDate = "";
$('#m_daterangepicker_1_modal').daterangepicker({
	buttonClasses: 'm-btn btn',
	applyClass: 'btn-primary',
	cancelClass: 'btn-secondary'
});

var	startDate = $("#m_daterangepicker_1_modal").data('daterangepicker').startDate;
var	endDate = $("#m_daterangepicker_1_modal").data('daterangepicker').endDate;

var _csrf_token = "<?php echo $this->security->get_csrf_token_name(); ?>";
var _csrf_hash = "<?php echo $this->security->get_csrf_hash(); ?>";

$('#m_daterangepicker_1_modal').on('apply.daterangepicker', function(ev, picker) {
  m_startDate = picker.startDate.format('MMMM DD, YYYY');
  m_endDate = picker.endDate.format('MMMM DD, YYYY');
});

var _dtTable = $("#table-receiving_report").DataTable({
	dom: 'B<"#irToolbar.toolbar">frtlip',
	serverSide: false,
	processing: false,
	ajax: {
		url: "<?php echo base_url("reports/receiving_data"); ?>",
		type: "post",
		dataType: "json",
		data: {  _csrf_token : _csrf_hash }
	}, columns: [
		{ data: "reference_no"},
		{ data: "sku"},
		{ data: "name"},
		{ data: "uom_code"},
		{ data: "qty"},
		{ data: "received_date"},
	],
	lengthMenu: [ [10, 20, 50, 100, 200, 500, -1], [10, 20, 50, 100, 200, 500, "All"] ],
	buttons: [
	      {
	          extend: 'pdfHtml5',
	          title: function(){
	          	return "Receiving Report as of "+ m_startDate + " to " + m_endDate;
	          },
	          orientation: 'portrait',
	          pageSize: 'LEGAL',
			  className: 'btnPdfAction',
			  filename: function(){
                return "Receiving Report as of "+ m_startDate + " to " + m_endDate;
            },
	      },
	      {
	        extend: 'excelHtml5',
	        title: function(){
	          	return "Receiving Report as of "+ m_startDate + " to " + m_endDate;
	          },
			className: 'btnExcelAction',
			filename: function(){
                return "Receiving Report as of "+ m_startDate + " to " + m_endDate;
            },
	    },
	  ],
	  initComplete: function(settings, json){
		$(".btnPdfAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".btnExcelAction").addClass("m-portlet__nav-link btn m-btn--square btn-warning text-white");
		$(".dt-buttons").appendTo("div#irToolbar");
		$("div.toolbar .dt-buttons").prepend('<button type="button" id="receiving_report-search" class="m-portlet__nav-link btn m-btn--square btn-primary btnAdvance_search"  data-toggle="modal" data-target="#m_daterangepicker_modal"><i class="fa fa-search"></i> Advance Search</button>');
		btnAction();
	}
});


var searchrange = function(){
	var form_searchdate = $("#form_searchdate");
	$.ajax({
		url: form_searchdate.attr("action"),
		type: "POST",
		dataType: "json",
		data: form_searchdate.serialize(),
		beforeSend: function()
		{
			mApp.blockPage({
				overlayColor: '#000000',
				type: 'loader',
				state: 'primary',
				message: 'Please wait...',
			});

			$(".blockUI.blockMsg .m-blockui").removeAttr("style");
			$(".blockUI.blockMsg.blockPage").css("z-index","2000");


		},
		success: function(json){
			_dtTable.clear();
			_dtTable.rows.add(json.data).draw();

			btnAction();
			$('#m_daterangepicker_modal').modal('hide');
			mApp.unblockPage();

		}
	});
}



function btnAction(){
	var dtCount = _dtTable.data().count();

	if(dtCount == 0){
		$(".buttons-pdf").attr("disabled","disabled");
		$(".buttons-excel").attr("disabled","disabled");
	}else{
		$(".buttons-pdf").removeAttr("disabled");
		$(".buttons-excel").removeAttr("disabled");
	}
}

</script>