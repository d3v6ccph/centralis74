<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Issuance extends MY_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("inventory/uom_model");
		$this->load->model("inventory/items_model");
		$this->load->model("issuance/issuance_model","issuance");
		$this->load->model("core/settings_model", "settings");
		
		date_default_timezone_set('Asia/Manila');
	}
	
	function index(){
		$this->core_layout->setPageTitle("Transaction - Issuance Slip");
		$this->core_layout->setBodyClass("transaction issuance_slip");
		$this->core_layout->setPrivilegeName("issuance_slip");
		
		$this->load->view('core/templates/header');
		$this->load->view('index');
		$this->load->view('core/templates/footer');
	}

	function get_issuance_list(){
		$data = $this->issuance->getIssuanceList();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function add_new_page(){
		$this->core_layout->setPageTitle("Transaction - Issuance New");
		$this->core_layout->setBodyClass("transaction issuance");
		$this->core_layout->setPrivilegeName("issuance_slip");

		$this->load->view('core/templates/header');
		$this->load->view('add_new_page');
		$this->load->view('core/templates/footer');
	}

	function get_issuance_content_temp(){
		$data = $this->issuance->getIssuanceContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_item_data(){
		$post = $this->input->post();
		$data = $this->issuance->getItemData($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function saveIssuance(){
		$post = $this->input->post();
		$data = $this->issuance->saveIssuance($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function add_issuance_content(){
		$post = $this->input->post();
		$data = $this->issuance->addIssuanceContentTemp($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function getIssuance(){
		$post = $this->input->post();
		$data = $this->issuance->getIssuance($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_issuance_content(){
		$post = $this->input->post();
		$data = $this->issuance->getIssuanceContent($post);
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function get_issuance_content_data(){
		$data = $this->issuance->getIssuanceContentData();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function remove_item_content_temp(){
		$data = $this->issuance->removeItemContentTemp();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function get_issuance_row_content(){
		$data = $this->issuance->getIssuanceRowContent();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function update_issuance_row_ccontent(){
		$data = $this->issuance->udpdateIssuanceRowContent();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function update_issuance_data(){
		$data = $this->issuance->updateIssuanceData();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function get_issuance_item_data(){
		$data = $this->issuance->getIssuanceItemData();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function update_issuance_item(){
		$data = $this->issuance->updateIssuanceItem();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
	
	function cancel_issuance(){
		$data = $this->issuance->cancelIssuance();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}

	function get_issuance_archives(){
		$data = $this->issuance->getIssuanceArchives();
		$this->output
        ->set_content_type('json')
        ->set_output(json_encode($data));
	}
}