<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Verifylogin extends MY_Controller {
	private $directAccess;
	/** e61a999de57725d7ce368a91ed87a7bd **/
	function __construct(){
		parent::__construct();
		$this->load->model('Login_m');
		$this->load->library('form_validation');
	}
	
	public function index(){
		//This method will have the credentials validation
		$this->form_validation->set_error_delimiters('<div class="m-alert m-alert--outline alert alert-danger alert-dismissible" role="alert">', '<button type="button" class="close" data-dismiss="alert" aria-label="Close"></button>
		<span></span>
		</div>');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|prep_for_form');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database|prep_for_form');
		
		if($this->form_validation->run() == FALSE){
			//Field validation failed.  User redirected to login page
			$this->load->view('login_v');
		}else{
			//Go to private area
			redirect('dashboard/index', 'refresh');
		}
	}

	function check_database($password){
		//Field validation succeeded.  Validate against database
		$username = $this->input->post('username');
		//query the database
		$result = $this->Login_m->login($username, $password);
		if($result){
			$id = $result['0']->id;
			$privileges = $this->Login_m->get_privileges_by_id($id);
			$sess_array = array();
			foreach($result as $row){
				if ($row->is_suspended == 1) {
					$this->form_validation->set_message('check_database', 'This user account is suspended.');
					return false;
				}else{
					$sess_array = array(
					'id' => $row->id,//tbluser_id
					'emp_id'=>$row->emp_id,
					'username' => $row->username,
					'firstname' => $row->firstname,
					'middlename' => $row->middlename,
					'lastname' => $row->lastname,
					'privileges' => $privileges,
					'suffix' => $row->suffix,
					'group_id' => $row->group_id,
					'email' => $row->email,
					'company' => $row->company_id,
					'department' => $row->department_id
					);
					$this->session->set_userdata('logged_in', $sess_array);
					return TRUE;
				}
			}
		}else{
			$this->form_validation->set_message('check_database', 'Invalid username or password');
			return false;
		}
	}
	
	function redirect_access($username, $password){
		$response = false;
		if($username && $password){
			$row = $this->Login_m->direct_login($username, $password);
			if($row){
				$id = $row->id;
				$privileges = $this->Login_m->get_privileges_by_id($id);
				$sess_array = array();
				
				if ($row->is_suspended == 1) {
					$response = false;
				} else {
					$sess_array = array(
						'id' => $row->id,
						'emp_id'=>$row->emp_id,
						'username' => $row->username,
						'firstname' => $row->firstname,
						'middlename' => $row->middlename,
						'lastname' => $row->lastname,
						'privileges' => $privileges,
						'suffix' => $row->suffix,
						'group_id' => $row->group_id,
						'email' => $row->email,
						'company' => $row->company_id,
						'department' => $row->department_id
					);
					
					$this->session->set_userdata('logged_in', $sess_array);
					$this->session->set_userdata('test_userdata', array('id'=>1, 'user'=>'test'));
					
					$response = true;
				}
			}else{
				$response = false;				
			}
		}else{
			$response = false;
		}
		return $response;
	}
}